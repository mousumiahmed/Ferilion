"""
Author : GOVIND 
Date   : 03-07-2024
"""

"""
string:
-------
sequence of characters
immutable 
ordered
sequence
iterable
'', "", ''' ''', """ """
47 - 

sequence type: string, list, tuple
-----------------------------------
Indexing - positive, negative
Slicing -
concatenate - with the same sequence type
multiply - with integers
min
max
len
in

python
-6 -5-4 -3 -2 -1
p  y  t  h  o  n
0  1  2  3  4  5
range(len(s)) - range(6) - 0 1 2 3 4 5

-12-11 -10 -9  -8  -7  -6  -5  -4  -3  -2  -1
p   y   t   h   o   n   .   w   o   r   l   d
0   1   2   3   4   5   6   7   8   9   10  11

len = 12 = -12, 0
"""
# n = "hello"
# print(s[0])
# print(s[1])
# print(s[2])

# for each in s:
#     print(each)

# for each in range(len(s)):
#     print(s[each])
# print(s[-5])
# for each in range(-(len(s)), 0):
#     print(s[each])

# part = s[2: 7]
# part = s[:5]
# part = s[5:]
# part = s[3: -2: 2]
#
# print(part)

# concatenating
# con = s + n
# print(con)

# mul = s * 6
# print(mul)

# print(len(s))
# count = 0

# for each in s:
#     count+=1
# print(count)

# print("p " in s)
# s = "🚦😀"

# s_min = min(s)
# s_max = max(s)
#
# print(f"min of '{s}' is '{s_min}'")
# print(f"max of '{s}' is '{s_max}'")


# p = '🚦'
# print(p)
# print(ord(p))
# print(id(p))
# print(chr(128678))

# q = "😀"
# print(q)
# print(ord("ඊ"))
# print(id(q))
# print(chr(1114112))
"""
Ǵ ᎈ 썐
"""
# r = "♞"
# print(r)
# print(ord(r))
# print(id(r))
# print(chr(9822))
# print("python" > "porld")

# string formats
# \t \n \\ \' \"

# r

print(())


str_meth = ['capitalize', 'casefold', 'center', 'count', 'encode',
            'endswith', 'expandtabs', 'find', 'format', 'format_map',
            'index', 'isalnum', 'isalpha', 'isascii', 'isdecimal',
            'isdigit', 'isidentifier', 'islower', 'isnumeric',
            'isprintable', 'isspace', 'istitle', 'isupper', 'join',
            'ljust', 'lower', 'lstrip', 'maketrans', 'partition',
            'removeprefix', 'removesuffix', 'replace', 'rfind', 'rindex',
            'rjust', 'rpartition', 'rsplit', 'rstrip', 'split',
            'splitlines', 'startswith', 'strip', 'swapcase', 'title',
            'translate', 'upper', 'zfill']

# print(len(str_meth))


"""
python world - lower
PYTHON WORLD - upper 
Python world - capitalize
Python World - title

join  - 
split -
strip -

"""
# ls = ["hello", "world", "python"]
# s = '*****'
# n = s.join(ls)
# print(n)
# ['python', ' hello world ', ' programming']
# s = "python, hello world , programming"
# n = s.rsplit()
# print(n)
# s = "hi, 썐"
# n = s.encode('utf-8')
# print(n, type(n))

# y = r"hi\tworld\nnewline \\ \'single\' \"double\""
# y = '"hi"'
#
# print(y)
# y = "python"
# print(y.rindex("y"))

# old style formatting - %s %d %f

# f-strings - 3.6+

# name = "Harish"
# age = 30
# salary = 10000.255634

# y = "name: %s, age: %f, salary: %d"%(name, age, salary)
# y = f"name: {name}, age: {age}, salary: {salary:.2f}"
# y = "name: {}, age: {}, salary: {:.2f}".format(name, age, salary)
# tp = ("Ramesh", 25, 1000.25662)
# y = "name: %s, age: %f, salary: %.2f"%(tp)
# y = f"{tp[0]}, {tp[1]}, {tp[2]}"
# y = "{1} {2} {0}".format(*tp)
# print(type(y))
# dc= {"name": "Rajesh", "age": 30, "salary": 1000.2564}
# y = " %(name)s, %(age)d, %(salary).2f"%(dc)
# y = f"{dc["name"]}, {dc["age"]}, {dc["salary"]:.3f}"
# y = "{name} {age} {salary}".format(**dc)
# print(y)


# str conversions - str() -
#
# s = 10
# x = str(s)
# print(x, type(x))

s = "python"
# print(s[::-1])
# '' + 'p' = p
# y + p  = yp
# t + yp = typ
# n = ''
# for each in s:
#     n = each + n
# print(n)
"""
s = "python"
s[0] = 'b'
print(s)
"""
#
# s = ["hello", "world", "python"]
# p = "new"
#
# y = p.join(s)
# print(y)
# print(s)
# print(p)