"""
Author : GOVIND 
Date   : 28-06-2024
"""
"""
Tokens:
-------



# 
# []
# ()
# {}
'' "" ''' ''' """ """

# comments
# s = {}
# print(type(set({})))
# 
# emp_name = "rajesh"
# 
# def add(x,y):
#     return x+y
# class MyRange:
#     pass
# > < == = != & ^ * **
# keywords - for if else True False break try except def class - 35

# for 
# while
# if
# and
# or



whitespace
----------
name = "python"
for each in range(10):
    print(each)
    print(name)

identifiers
variable names, function names, class names

"""

"""
variables:
-----------
let x = 10

name = "Rajesh"
lhs  = rhs

a-z A-Z _ __ followed by a-z A-Z _ __ 0-9
keywords - 35 - we should not use 
case sensitive

gc
"""
# num1 = 20
# num2 = num1 # dt ds
# for  = 10 - xx
# num1 = 10
# _1num = 10

# age = 30
# Age = 20
# AGe = 40
# AGE = 50
# AgE = 60

# x = "Rajesh"
# y = 30
#
# name = "Ramesh"
# age = 40
#
# print(name)
# print(age)

# LEGB
# from math import pi

# pi = "global space"

#
# def outer():
#     # pi = "enclosed space"
#
#     def inner():
#         # pi = "local space"
#         print(pi)
#
#     return inner()
#
#
# outer()


name = "Rajesh"
# # print(id(name))
name = "suresh"
# # print(id(name))
#
print(name)
print(name)

# x=y=z= 10
#
# print(x)
# print(y)
# print(z)

# non -iterables : int, float, complex, bool
# iterables     : string, list, tuple, set, dict, iterable
# x, y, z = "pyt"
# print(x)
# print(y)
# print(z)
"""
immutable : int, float, complex, bool, string, tuple - CRD
mutable   : list, set, dict - CRUD

CRUD
"""
# n1 = True
# n2 = True
# print(id(n1))
# print(id(n2))
# num = 10
# print(id(num))
# print(num)
# num = num + 10 # num = 20
# print(id(num))
# del num
#
# ls = [1, 2, 3]
# print(id(ls))
# ls.append(9)
# print(id(ls))
ls1 = ""
ls2 = ""

print(id(ls1))
print(id(ls2))