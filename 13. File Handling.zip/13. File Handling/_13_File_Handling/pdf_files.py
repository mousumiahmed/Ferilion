"""
Author : GOVIND 
Date   : 01-08-2024
"""

# pip install pypdf2
from PyPDF2 import PdfReader, PdfWriter

#
# # Create (Combine PDF files)
# def create_pdf(output_file, input_files):
#     pdf_writer = PdfWriter()
#     for file in input_files:
#         pdf_reader = PdfReader(file)
#         for page_num in range(pdf_reader.numPages):
#             page = pdf_reader.getPage(page_num)
#             pdf_writer.addPage(page)
#     with open(output_file, 'wb') as output_pdf:
#         pdf_writer.write(output_pdf)


# Read (Extract text)
def read_pdf(file_name):
    pdf_reader = PdfReader(file_name)
    text = []
    for page_num in range(len(pdf_reader.pages)):
        page = pdf_reader.pages[page_num]
        text.append(page.extract_text())
    return text
# print(read_pdf('file1.pdf'))


# Update (Append a page from another PDF)
# def update_pdf(file_name, page_to_add):
#     pdf_reader_main = PdfReader(file_name)
#     pdf_reader_to_add = PdfReader(page_to_add)
#     pdf_writer = PdfWriter()
#
#     for page_num in range(len(pdf_reader_main.pages)):
#         pdf_writer.add_page(pdf_reader_main.pages[page_num])
#
#     pdf_writer.add_page(pdf_reader_to_add.pages[0])
#
#     with open(file_name, 'wb') as output_pdf:
#         pdf_writer.write(output_pdf)
# update_pdf('file1.pdf', 'file1.pdf')
# print(read_pdf('file1.pdf'))

# Delete (Remove a specific page)
# def delete_pdf_page(file_name, page_num_to_delete):
#     pdf_reader = PdfReader(file_name)
#     pdf_writer = PdfWriter()
#
#     for page_num in range(len(pdf_reader.pages)):
#         if page_num != page_num_to_delete:
#             pdf_writer.add_page(pdf_reader.pages[page_num])
#
#     with open(file_name, 'wb') as output_pdf:
#         pdf_writer.write(output_pdf)
# delete_pdf_page('file1.pdf', 0)
# print(read_pdf('file1.pdf'))
#
#

