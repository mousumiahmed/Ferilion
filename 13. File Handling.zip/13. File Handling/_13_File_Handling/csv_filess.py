"""
Author : GOVIND 
Date   : 01-08-2024
"""

import csv


# Create (Write)
def create_csv(file_name, data):
    with open(file_name, 'w', newline="") as file:
        writer = csv.writer(file)
        writer.writerows(data)
#
#
data = [['Name', 'Age'], ['Rajesh', 30], ['Harish', 25]]
create_csv('example.csv', data)


# Read
def read_csv(file_name):
    with open(file_name, 'r') as file:
        reader = csv.reader(file)
        return list(reader)

#
# print(read_csv('example.csv'))
#
#
# # Update
# def update_csv(file_name, row_index, new_row):
#     data = read_csv(file_name)
#     data[row_index] = new_row
#     create_csv(file_name, data)
#
#
# update_csv('example.csv', 1, ['Suresh', 31])
# print(read_csv('example.csv'))
#
#
# # Delete
# def delete_csv_row(file_name, row_index):
#     data = read_csv(file_name)
#     data.pop(row_index)
#     create_csv(file_name, data)
#
#
# delete_csv_row('example.csv', 1)
# print(read_csv('example.csv'))
