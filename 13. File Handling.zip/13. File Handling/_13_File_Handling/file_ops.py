"""
Author : GOVIND
Date   : 01-08-2024
"""
import os
import shutil

# opening a file in 'r' mode
# 'r': Open the file for reading (default)
# This mode is used for reading from a file.
# If the file doesn't exist, it will raise a FileNotFoundError.

# with open('example.txt', 'r') as file:
#     data = file.read()
#     print(data)
#     print(type(data))
#
# # opening a file in 'w' mode
# # 'w': Open the file for writing. Existing content will be overwritten!
# # This mode is used for writing to a file. If the file exists, it will be overwritten.
# # If the file doesn't exist, it will be created.
#
# with open('example.txt', 'w') as file:
#     file.write("Hello, world!")

# # 'a': Open the file for appending. New data will be written to the end of the file.
# # This mode is used for appending data to the end of a file.
# # If the file doesn't exist, it will be created.
# # opening a file in 'a' mode
# with open('new.txt', 'a') as file:
#     file.write("Appending new data!")

#
# # opening a file in 'r+' mode
# # 'r+': Open the file for both reading and writing (from the beginning).
# # This mode is used for both reading and writing from the beginning of a file.
# # If the file doesn't exist, it will raise a FileNotFoundError.
#
# with open('demo.txt', 'r+') as file:
    # data = file.read()
    # print(data)
    #
    # file.seek(10)
    # file.write("Apple")
    # file.seek(25)
    # data = file.read()
    # print(data)
#
# # opening a file in 'w+' mode
# # 'w+': Open the file for both reading and writing. Existing content will be overwritten!
# # This mode is used for both reading and writing.
# # If the file doesn't exist, it will be created.
#
# with open('demo.txt', 'w+') as file:
#     file.seek(10)
#     file.write("Hello, world!")
#     file.seek(0)  # Move the cursor to the beginning of the file
#     data = file.read()
#     print(data)



# # opening a file in 'a+' mode
# # 'a+': Open the file for both reading and appending.
# # This mode is used for both reading and appending.
# # If the file doesn't exist, it will be created.
#
# with open('demo3.txt', 'a+') as file:
#     # file.seek(0)
#     file.write("Appending new data!")
#     file.seek(0)  # Move the cursor to the beginning of the file
#     data = file.read()
#     print(data)
"""
file1 - content is present - 
file2 - content is present

"""
#
# # opening a file in 'x' mode
# # 'x': Opens the file for exclusive creation, failing if the file already exists.
# # This mode is used to create a file exclusively.
# # If the file already exists, it will raise a FileExistsError.
#
# try:
#     with open('demo2.txt', 'x') as file:
#         file.write("This is a new file created exclusively!")
# except Exception as e:
#     print(e)
#     print("File already exists")

# # Read text from a text file
# with open('example.txt', 'r') as text_file:
#     text_content = text_file.read()
#
# # Write the text content to a binary file
# with open('binary_file.bin', 'wb') as binary_file:
#     binary_file.write(text_content.encode('utf-8'))
#
# print("Text file converted to binary file successfully.")
#
#
# seek
# Open a file in read mode
# with open('example.txt', 'r') as file:
#     # Read the first 10 bytes
#     data = file.read()
#     print("Initail data ", data)
#     # Reposition the cursor to the beginning of the file
#     file.seek(10)
# #
#     # Read the entire file content again
#     data = file.read()
#     print("Full Content:", data)


with open('example.txt', 'r') as file:
    # read_data = file.readline()
    # read_data_2 = file.readline()
    # file.seek(0)
    data = file.readlines()
    # print("read_data:", read_data)
    # print("read_data_2:", read_data_2)
#
    print("readlines data ", data)


# file = open(filename or path, mode)
#   perform action
# close the file

ls = ['this is the first line\n', 'I am from second line\n', 'this is the third line\n', 'and final is the fourth line\n']