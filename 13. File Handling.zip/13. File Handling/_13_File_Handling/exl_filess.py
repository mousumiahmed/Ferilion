"""
Author : GOVIND 
Date   : 01-08-2024
"""

# pip install openpyxl
# use openpyxl for .xlsx files.

import openpyxl


# Create (Write)
def create_excel(file_name, sheet_name, data):
    wb = openpyxl.Workbook()
    sheet = wb.active
    sheet.title = sheet_name

    for row in data:
        sheet.append(row)

    wb.save(file_name)


data = [['Name', 'Age'], ['Rajesh', 30], ['Harish', 25]]
create_excel('example.xlsx', 'Sheet1', data)


# Read
def read_excel(file_name, sheet_name):
    wb = openpyxl.load_workbook(file_name)
    sheet = wb[sheet_name]
    return [[cell.value for cell in row] for row in sheet.iter_rows()]


print(read_excel('example.xlsx', 'Sheet1'))


# Update
def update_excel(file_name, sheet_name, row_index, new_row):
    wb = openpyxl.load_workbook(file_name)
    sheet = wb[sheet_name]

    for col_index, value in enumerate(new_row, start=1):
        sheet.cell(row=row_index, column=col_index, value=value)

    wb.save(file_name)


update_excel('example.xlsx', 'Sheet1', 2, ['Suresh', 31])
print(read_excel('example.xlsx', 'Sheet1'))


# Delete
def delete_excel_row(file_name, sheet_name, row_index):
    wb = openpyxl.load_workbook(file_name)
    sheet = wb[sheet_name]
    sheet.delete_rows(row_index)
    wb.save(file_name)


delete_excel_row('example.xlsx', 'Sheet1', 2)
print(read_excel('example.xlsx', 'Sheet1'))
