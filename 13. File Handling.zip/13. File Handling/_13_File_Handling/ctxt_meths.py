"""
Author : GOVIND
Date   : 01-08-2024
"""


def manipulate_file(filename):
    """  """
    # 1. Create a file if it doesn't exist (using 'x' mode)
    # try:
    #   with open(filename, "x") as file:
    #     file.write("This is the initial content.\n")
    #     print(f"File '{filename}' created successfully!")
    # except FileExistsError:
    #   print(f"File '{filename}' already exists. Proceeding with operations...")

    # # 2. Add content to the file (append mode)
    # with open(filename, "a") as file:
    #   file.write("This line is appended to the existing content.\n")
    #
    # # 3. Add a new line to the file (append mode)
    # with open(filename, "a") as file:
    #   file.write("\n")  # Write an empty line for a new line
    # #
    # # 4. Add another new line to the content (append mode)
    # with open(filename, "a") as file:
    #   file.write("Another line is added.\n")

    # 5. Read the first line from the file
    # with open(filename, "r") as file:
    #   first_line = file.readline().strip()  # Remove trailing newline
    #   print(f"First line: {first_line}")

    # 6. Read a particular line from the file (assuming 3rd line)
    # Note: Be cautious with line numbers for dynamic content
    # with open(filename, "r") as file:
    #   lines = file.readlines()  # Read all lines into a list
    #   if len(lines) >= 3:  # Check if there are at least 3 lines
    #     third_line = lines[2].strip()
    #     print(f"Third line: {third_line}")
    #   else:
    #     print("The file may not have 3 lines yet.")

    # # 7. Read all the lines from the file
    # with open(filename, "r") as file:
    #   all_lines = file.readlines()
    #   print("\nAll lines:")
    #   for line in all_lines:
    #     print(line.strip())  # Print each line without trailing newline

    # # 8. Update the first line from the file (read-write mode)
    # with open(filename, "r+") as file:
    #   lines = file.readlines()
    #   lines[0] = "This is the updated first line.\n"
    #   file.seek(0)  # Move the file pointer to the beginning
    #   file.writelines(lines)  # Rewrite the entire content with modifications
    #
    # # 9. Delete the second line from the file (read-write mode)
    # with open(filename, "r+") as file:
    #   lines = file.readlines()
    #   del lines[1]  # Remove the second line (index 1)
    #   file.seek(0)
    #   file.writelines(lines)
    #
    # # 10. Overwrite the existing content from the file (write mode)
    # with open(filename, "w") as file:
    #   file.write("The existing content is overwritten.\n")
    #
    # 11. Delete all the content from the file (write mode, truncate)
    # with open(filename, "w") as file:
    #   file.truncate()  # Truncates the file to zero length (effectively deletes content)


# Example usage
filename = "my_file.txt"
manipulate_file(filename)
