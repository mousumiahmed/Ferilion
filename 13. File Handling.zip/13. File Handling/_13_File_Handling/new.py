"""
Author : GOVIND 
Date   : 01-08-2024
"""
"""
file handling:
---------------

file = open('filename/path', mode)
# action part - dependent on the mode
file.close()

mode:

r - 
w - 
a - 

r+
w+
a+

x - 

context manager:
-----------------
with open('filename/path', mode):
    # action part
    
"""

