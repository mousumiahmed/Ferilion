"""
Author : GOVIND 
Date   : 29-06-2024
"""
"""
req:
----
state - input output - dt/ds

dt/ds
int, float, complex, bool, string, list[], tuple(), set{} , dictionary{key:value}

req: add two positive integers and provide the result

input state  : two int - 2, 3
behavior     : B.L - CRUD - DM, LOOPS, OPERATORS (res = n1 + n2 -> print(res))
output state : int     - 5

CREATE
RETRIEVE
UPDATE
DELETE
"""

"""
mutable   : list, set, dictionary
immutable : int, float, complex, tuple, bool, string

iterables: string, list, tuple, set, dictionary, range

numbers, words, bool, None

numbers:
--------
immutable

int     - ....-3,-2,-1,0,1,2.....
float   - 3.5 
complex - 3+4j


characters - sequence of characters
-------------------------------------
strings - 'a' - dt , 'python' - ds - 47
'', "", ''' ''', """ """
immutable

bool
----
immutable

True False
  1    0



datastructures:
-----------------
list  - mutable - ordered - sequence type - [] - any kind of dt/ds - 11 

tuple - immutable - ordered - sequence type - () - any kind of dt/ds - 2 


Note: Sequence type: string, list, tuple
----------------------------------------

set type:
---------
set  - mutable - unordered - unique elements - only immutable dt/ds - {} - empty - set() - set({}) - 17

mapping type:
------------
dictionary - mutable - key, value pairs - keys: unique elements - only immutable dt/ds - {} - 11
            ordered(3.7+)


None
-----
0 vs None

range
------
finite sequence of numbers

range(n)       - start: 0, stop: n, step: 1, last value: n-1, num of elements: stop - start (n - 0)
range(m, n)    - start: m, stop: n, step: 1, last value: n-1, num of elements: stop - start (n - m)
range(p, q, r) - start: p, stop: q, step: r, 
Note
-----
for range(p,q,r)
num of elements  : ciel((q-p)/r)

if step r is positive : 
last value : p+floor((q-p-1)/r)*(r)

if step r is negative :
last value : p+floor((q-p+1)/r)*(r)

"""
# emp_id = [25, 35, 26, 27] # homogenous - same kind of data
# emp_data = [25, "Rajesh", 10000.52, True, ["chennai", "bangalore"],
#             ("9874651230", "BPTIP2510Y"), {2,4}, {"k":"v"}, None, 3+5j] # Hetrogenous
#
# # n = None
# # n = 100
#
# dc = {"name": "Rajesh", "age": 30, "salary": 25000}
# emp_details = ["rajesh", 30, "chennai", 25000, True]
# # print(dc)
#
# st = {1, 1, 2, 1}
# # print(st)
#
# # strings, list, tuple -  sequence types
#
# tp = (10,)
# print(type(tp))

# r = range(5, 25, 5)
#
# # 5 8 11 14 17 20 23 - 3
# # 5 7 9 11 13 15 17 19 21 23 - 2
# # 5 10 15 20 - 5
# for each in r:
#     print(each)
# # print(r)

# r = range(5, 25)
# r = range(25, 5, -1)
# # 25 5 -(-1) = 6, -1
# count = 0
# for each in r:
#     print(each)
#     count += 1
# print(count)
#
#
# r = range(25, 5, -1)
# r = range(-5, -25, -3)

# for each in r:
#     print(each)
