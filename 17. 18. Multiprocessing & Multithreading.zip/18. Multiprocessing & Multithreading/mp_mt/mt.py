"""
Author : GOVIND
Date   : 07-08-2024
"""

import time
import threading
import os

start = time.time()
def sleeping_function():
    print('Sleeping 1 second...')
    time.sleep(1)
    print('Done Sleeping...')
    print('parent process:', os.getppid())
    print('process id:', os.getpid(), '\n')

#
# sleeping_function()
# sleeping_function()
# #
# finish = time.time()
# #
# print(f'Finished in {round(finish - start, 2)} seconds')

t1 = threading.Thread(target=sleeping_function)
t2 = threading.Thread(target=sleeping_function)
# to call the function we need to run the threads by calling start method
t1.start()
t2.start()

t1.join()
t2.join()
finish = time.time()
# print("finish", finish)

print(f'Finished in {round(finish - start, 2)} seconds')









# Another way

# threads = []
# for _ in range(10):
#     t = threading.Thread(target=sleeping_function)
#     t.start()
#     # t.join()
#     threads.append(t)
# for each in threads:
#     each.join()
# finish = time.time()
#
# print(f'Finished in {round(finish - start, 2)} seconds')
