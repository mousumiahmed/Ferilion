"""
Author : GOVIND
Date   : 07-08-2024
"""

import time
import multiprocessing
import os

start = time.time()


def sleeping_function():
    print('Sleeping 1 second...')
    # time.sleep(1)
    print('Done Sleeping...')
    print('parent process:', os.getppid())
    print('process id:', os.getpid(), '\n')
#
# sleeping_function()
# sleeping_function()
#
# finish = time.time()
#
# print(f'Finished in {round(finish - start, 2)} seconds')








#
if __name__ == "__main__":
    pr1 = multiprocessing.Process(target=sleeping_function)
    pr2 = multiprocessing.Process(target=sleeping_function)

    pr1.start()
    pr2.start()

    pr1.join()
    pr2.join()

    finish = time.time()

    print(f'Finished in {finish - start} seconds')
#
#


 # Another Way
# if __name__ == "__main__":
#
#     process = []
#
#     for _ in range(10):
#         pr = multiprocessing.Process(target=sleeping_function)
#         pr.start()
#         process.append(pr)
#     for each_process in process:
#         each_process.join()
#     finish = time.time()
#
#     print(f'Finished in {round(finish - start, 2)} seconds')
