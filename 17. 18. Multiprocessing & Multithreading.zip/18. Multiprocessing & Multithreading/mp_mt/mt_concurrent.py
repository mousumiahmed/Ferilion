"""
Author : GOVIND
Date   : 07-08-2024
"""

import time
import concurrent.futures
import os

start = time.time()


def sleeping_function(ss):
    print(f'Sleeping {ss} second...')
    time.sleep(ss)
    return f'Done Sleeping for {ss}...parent process : {os.getppid()}, process id : {os.getpid()}'

with concurrent.futures.ThreadPoolExecutor() as executor:
    res = [executor.submit(sleeping_function, 1) for _ in range(10)]
    print(res)
    for each in concurrent.futures.as_completed(res):
        print(each.result())

finish = time.time()
print(f'Finished in {round(finish - start, 2)} seconds')



# # using map to pass different args

# with concurrent.futures.ThreadPoolExecutor() as executor:
#     seconds = [5, 4, 3, 2, 1]
#     results = executor.map(sleeping_function, seconds)
#
#     for result in results:
#         print(result)
# finish = time.time()
# print(f'Finished in {round(finish - start, 2)} seconds')
