"""
Author : GOVIND 
Date   : 05-08-2024
"""

# def dec(func):
#     def wrapper(*args, **kwargs):
#         bef = "before calling the function"
#         res = func(*args, **kwargs)
#         aft = "before calling the function"
#         return bef, res, aft
#     return wrapper

# def outer(param):
#     def dec(func):
#         def wrapper(*args, **kwargs):
#             bef = "before calling the function"
#             res = func(*args, **kwargs)
#             aft = "before calling the function"
#             return bef, res, aft, param
#         return wrapper
#     return dec

# class Decorator:
#
#     def __init__(self, func):
#         self.func = func
#
#     def __call__(self, *args, **kwargs):
#         return self.func(*args, **kwargs), "Hello from class decorator"
# @dec
# @outer(param= 100)

#
# def dec1(func):
#     def wrapper(*args, **kwargs):
#         bef = "from line 38 in dec1"
#         res = func(*args, **kwargs)
#         aft = "from line 40 in dec1"
#         return bef, res, aft
#     return wrapper
#
# def dec2(func):
#     def wrapper(*args, **kwargs):
#         bef = "from line 46 in dec2"
#         res = func(*args, **kwargs)
#         aft = "from line 48 in dec2"
#         return bef, res, aft
#     return wrapper

# @Decorator
# @dec1
# @dec2
# def hello(x, y):
#     return x + y
#
# y = hello(2, 3)
# print(y)


# def decorataor(any):
#     class Myclass(any):
#         def myclass_instance(self):
#             return "from Myclass"
#     return Myclass
#
#
# @decorataor
# class NewClass:
#     def meth(self):
#         return "from new class"
#
# obj = NewClass()
# print(obj.meth())
# print(obj.myclass_instance())

"""
iterables - __iter__
iterators - __iter__, __next__

by using a class iterators - __iter__, __next__

generator expression

functions - yield keyword
"""
# def hello():
#     # yield 1
#     # yield 2
#     # yield 3
#     ls = [1, 2, 3]
#     for each in ls:
#         yield each
#
# print(hello())
# y = hello()
# # # print(list(y))
# print(next(y))
# print(next(y))
# print(next(y))
# print(next(y))


# print(next(hello()))
# print(next(hello()))
# print(next(hello()))

# print(dir(list))
# ls = [2, 4, 6, 8]
# itr_list = iter(ls)
# print(itr_list)
# print(dir(itr_list))
# print(next(ls))
# print(next(itr_list)) # 2
# print(next(itr_list)) # 2
# print(next(itr_list)) # 2
# print(next(itr_list)) # 2
# print(next(itr_list)) # 2



# for each in itr_list:
#     print(each, "hi")

# 2 2 4 6 8
# 2 4 6 8

# gen = (x**2 for x in range(5))
# # print(gen)
# print(next(gen))
# for each in gen:
#     print(each)

# ls = [1, 2, 3]
# y = iter(ls)
# print(y)
# 2, 5 , +1
# 2 , 2+1 , 3+1 -2 ,3 ,4 5 -> raise StopIteration

# z = iter(y)
# print(z)
# class RangeItearator:
#     def __init__(self, start, stop):
#         self.start = start
#         self.stop = stop
#
#     def __iter__(self):
#         return self
#
#     def __next__(self):
#         current = self.start
#         if self.start >= self.stop:
#             raise StopIteration
#         self.start += 1
#         return current
#
# y = RangeItearator(2, 5)
# print(next(y))
# # print(next(y))
# # print(next(y))
# # print(next(y))
# for each in y:
#     print(each)
#
#

# def range_gen(start, stop):
#     # current = start
#     while start < stop:
#         # print(start)
#         yield start
#         start+= 1
#         print("start")

def range_gen(start, end):
    current = start
    while current < end:
        yield current
        current += 1

y = range_gen(2, 500000000000000000)
print(y)
for _ in range(5):
    print(next(y))
# print(next(y))
# print(next(y))
# print(next(y))
# print(next(y))

# for each in y:
#     print(each)


# ls = [1, 2, 3]
# ls_it = iter(ls)
# ls_new_it = iter(ls_it)
# ls_new_it.__iter__()
# ls_new_it.__next__()
# print(ls_it)

# print(next(ls_it))
# print(next(ls_it))
# print(next(ls_it))
# print(next(ls_it))

"""
with open('filename/path', mode) as file:
    as per the mode action part
    
    
modes - r   w   a
        r+  w+  a+  
        x
file.read()
file.write()
file.append()


"""