"""
Author : GOVIND
Date   : 31-07-2024
"""


"""
try:
    name = "python"
    # print(nae)
    print(10/0)
    # ls = [1, 2]
    # print(ls[2])
except NameError as ne:
    # print("naem is not defined")
    print(ne)
# except ZeroDivisionError as ze:
#     print(ze)
# except (NameError, ZeroDivisionError) as e:
#     print(e)
# except NameError or ZeroDivisionError as nze:
#     print(nze)
# except Exception as e:
#     print(e)
    # print("I am from Exception block")
# except IndexError as ie:
#     print("i am from index error block")
# else:
#     print("this else block will execute only if there are no exception occurs")
# finally:
#     print("finally block will get excuted regardless of exception occurs or not")


"""
#
# try:
#     # Code that might raise an exception
#     x = int(input("Enter a number: "))
#     result = 10 / x
# except Exception as e:
#     # return " give  a proper integer value"
#     print(e)
# # except ZeroDivisionError as z:
# #     return "you are dividing with zero"
# else:
#     print(result)
# finally:
#     print( "I will always be executed")
#
#

# try:
#     # Code that might raise an exception
#     x = int(input("Enter a number: "))
#     result = 10 / x
# except ValueError:
#     # Handle ValueError (e.g., if the user enters a non-integer)
#     print("Please enter a valid integer.")
# except ZeroDivisionError:
#     # Handle ZeroDivisionError (e.g., if the user enters 0)
#     print("Cannot divide by zero.")
# else:
#     # Executed if no exceptions occur
#     print("Division result:", result)
# finally:
#     # Always executed, regardless of exceptions
#     print("Finally block: This will always be executed.")


# try:
#     my_list = [1, 2, 3]
#     print(my_list[3])
# except IndexError as e:
#     print("Error:", e)
#
# try:
#     my_dict = {"key": "value"}
#     print(my_dict["nonexistent_key"])
# except KeyError as e:
#     print("Error:", e)
#
# def add_numbers(a, b):
#     return a + b
# try:
#     add_numbers("1", 2)
# except TypeError as e:
#     print(e)
#
# def divide(x, y):
#     try:
#         res = x /y
#     except ZeroDivisionError as e:
#         return "Error: " + str(e)
#     else:
#         return res
# x = divide(10 ,0)
# print(x)