"""
Author : GOVIND 
Date   : 31-07-2024
"""
"""
Exception Handling:
-------------------
syntax   - 
runtime  - 
semantic -

try:
block of code any runtime errors

except
handling those runtime errors

else :
if no run time error occurs -

finally : always going to be executed
if runtime error occurs or doesn't occurs

"""
# try:
#     # dc = {"a": 100}
#     # print(dc["b"])
#     # a = 10
#     # b = 0
#     # print(a/b)
#     ls1 = [1, 2, 3]
#     # print(ls[3])
#     d = {"100": 100}
#     # dc = {"ls": "ls1[3]", "a": "name", "ls1": 10/0, b: d["a"]}
#     # dc = {ls1: ls1[0], "ls": 10, "a": 10/0}
#     # ls = ["name", "d['a']", 10/0]

# except Exception as e:
#     print(e)
# except (Exception, IndexError) as ze:
#     print(f"ze = {ze}")
# except IndexError as ie:
#     print(f"ie = {ie}")
# except KeyError as ke:
#     print(f"ke = {ke}")

# except Exception as e:
#     print(e)
# except (IndexError, KeyError, ZeroDivisionError) as e:
#     print(e)
#
# except IndexError:
#     print("The provided list doesnot contain the index 3")

# print("name")

# d= {[1]: 200}
# print(d)

# try:
#     ls = [1, 2, 3]
#     x = ls[0]
#     z = x * 100
#     print(z)
#     print("x is", x)
# except Exception as e:
#     print("from except block")
# # else:
# #     print("from else block")
#
# finally:
#     print("from finally block")
#     print(x)
#     # print(ls)
#
# ls = [1, 2, 3]
# print(ls[3])

# def some(x):
#     if not isinstance(x, int):
#         raise ValueError("hi")
#     print(x)
# try:
#     some("100")
# except Exception as e:
#     print(e)

# class CustomException(Exception):
#     pass
#
# def some(x):
#     if not isinstance(x, int):
#         raise CustomException("hi")
#     print(x)
# try:
#     some("100")
# except CustomException as e:
#     print(e)

class CustomHTTPException(Exception):
    def __init__(self, message, status_code):
        self.message = message
        self.status_code = status_code

def some(x):
    if not isinstance(x, int):
        raise CustomHTTPException("Expected Value is integer", 400)
    print(x)
try:
    some("100")
except CustomHTTPException as e:
    print(e.message, e.status_code)
