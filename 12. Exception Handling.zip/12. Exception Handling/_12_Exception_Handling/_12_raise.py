"""
Author : GOVIND
Date   : 31-07-2024
"""

#
# def divide(x, y):
#     if y == 0:
#         raise ZeroDivisionError("Division by zero")
#     return x / y
# try:
#     result = divide(10, 0)
# except ZeroDivisionError as e:
#     print("Error:", e)

# def divide(x, y):
#     return x / y
#
# try:
#     result = divide(10, 0)
# except ZeroDivisionError as e:
#     print("Error:", e)


# class CustomExceptionError(Exception):
#     pass
#
#
# def validate_input(value):
#     if not isinstance(value, int):
#         raise CustomExceptionError("Input must be an integer")
#
#
# try:
#     validate_input("abc")
# except CustomExceptionError as e:
#     print("Error:", e)
#
#
# #
#
# class CustomError(Exception):
#     def __init__(self, message, code):
#         self.message = message
#         self.code = code
#
#
# x = 10
# try:
#     if x == 15:
#         raise CustomError("Custom error message", 500)
# except CustomError as e:
#     print("Error message :", e.message)
#     print("Error code    :", e.code)
