"""
Author : GOVIND
Date   : 05-08-2024
"""
import datetime

# Returns the current date and time
current_datetime_now = datetime.datetime.now()
print("Current Date and Time        : ", current_datetime_now)
#
# # Returns the current date without time information
current_date_today = datetime.date.today()
print("Current Date                 : ", current_date_today)
#
# # Returns the current date and time in UTC
# utc_datetime = datetime.datetime.utcnow()
# print("Current Date and Time in UTC:", utc_datetime)
#
# #
utc_dt = datetime.datetime.now(datetime.timezone.utc)
print("Current Date and Time in UTC : ", utc_dt)
