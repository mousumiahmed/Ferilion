"""
Author : GOVIND 
Date   : 07-08-2024
"""

"""
created_at
updated_at 

datetime

date      - today's date, create a date
time      - 
datetime  -
timedelta - 

06-08-2024
08-06-2024
2024-08-06

strptime strftime

"""