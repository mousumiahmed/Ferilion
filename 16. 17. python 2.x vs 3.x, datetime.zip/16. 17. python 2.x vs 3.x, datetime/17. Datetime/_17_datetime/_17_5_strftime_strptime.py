"""
Author : GOVIND
Date   : 05-08-2024
"""

# https://docs.python.org/3/library/datetime.html#strftime-and-strptime-format-codes

import datetime

# Create a datetime object
# now = datetime.datetime.now()
# print(now)
# print(type(now))

# strftime
# To format a datetime object into a string
# formatted_date = now.strftime("%d/%Y-%m- %H:%M:%S")
# print("Formatted date :", formatted_date)
# print("Formatted date :", type(formatted_date))



# strptime
# Parse a string into a datetime object
date_string = "24-04-04 12:30:00"
parsed_date = datetime.datetime.strptime(date_string, "%y-%m-%d %H:%M:%S")
print("Parsed date    :", parsed_date)
print("Parsed date    :", type(parsed_date))

