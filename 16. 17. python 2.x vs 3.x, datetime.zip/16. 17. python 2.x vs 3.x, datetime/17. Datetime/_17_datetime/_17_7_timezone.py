"""
Author : GOVIND
Date   : 05-08-2024
"""
# pip install python-dateutil
# pip install pytz
# https://pypi.org/project/pytz/
import pytz

# to fetch all timezones
# all_timezones = pytz.all_timezones
# #
# for timezone in all_timezones:
#     print(timezone)
#
# # Changing from one timezone to another timezone
# import datetime
# import pytz
#
# # # Define a datetime object in a specific timezone
# original_datetime = datetime.datetime(2024, 8, 8, 14, 40, 0, tzinfo=pytz.timezone('Asia/Calcutta'))
# # #
# # # # Convert the datetime object to another timezone
# target_timezone = pytz.timezone('America/New_York')
# converted_datetime = original_datetime.astimezone(target_timezone)
# # #
# print("Original datetime () :", original_datetime)
# print("Converted datetime ()  :", converted_datetime)
# # #

from datetime import datetime, timezone, timedelta

# offset = timedelta(hours=5, minutes=30)
# tz = timezone(offset)

# Get the current time with the specified timezone
# current_time = datetime.now(tz)

# Print the current time with offset
# print(current_time.isoformat())
# print(datetime.now())

# from datetime import datetime
# from dateutil import tz
#
# # Define the timezone
# timezone = tz.gettz('Asia/Kolkata')
#
# # Get the current time with the specified timezone
# current_time = datetime.now(timezone)
#
# # Print the current time with offset
# print(current_time.isoformat())


# from datetime import datetime, timezone, timedelta
#
# utc_time = datetime.now(timezone.utc)
# print(timezone.utc)
#
# offset = timedelta(hours=5, minutes=30)
#
# current_time = utc_time + offset
#
# print(current_time.isoformat())