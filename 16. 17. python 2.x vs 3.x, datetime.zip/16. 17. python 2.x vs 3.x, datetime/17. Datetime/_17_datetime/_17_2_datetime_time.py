"""
Author : GOVIND
Date   : 05-08-2024
"""
import datetime
# milliseconds - 1/1000
# microseconds - 1/1000000
# current_time = datetime.time(15, 30, 0)
# print(current_time)

# # Create a time with microseconds
meeting_time = datetime.time(10, 0, 0, 1000)
print(meeting_time)
#
#
current_time = datetime.time(15, 30, 0)
print(f"Current time: {current_time}")  # Output: 15:30:00

# # Attributes
# print(f"Hour        : {current_time.hour}")
# print(f"Minute      : {current_time.minute}")
# print(f"Second      : {current_time.second}")
# print(f"Microsecond : {current_time.microsecond}")
#
# # Methods
new_time = current_time.replace(minute=45)
print(f"New time   : {new_time}")
iso_format = current_time.isoformat()
print(f"ISO format : {iso_format}")
