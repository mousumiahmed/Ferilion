"""
Author : GOVIND
Date   : 05-08-2024
"""
# import datetime
# # Two days from now
# two_days_later = datetime.timedelta(days=2, minutes=30)
# print(type(two_days_later))
# print(f"two_days_later ; {two_days_later}")
# today = datetime.datetime.now()
# print(f"todays date    : {today}")
# future_date = today + two_days_later
# print(future_date)  # Output: (depending on today's date) YYYY-MM-DD (two days from now)
#
import datetime

td1 = datetime.timedelta(days=2, hours=3, minutes=10)
td2 = datetime.timedelta(hours=5, seconds=30)
print("td1 :", td1)
print("td2 :", td2)

# Operations
td3 = td1 + td2
print(f"Combined duration    : {td3}")

# # Methods
total_seconds = td1.total_seconds()
print(f"Total seconds in td1 : {total_seconds}")
# #
# # # Attributes
print(f"Days in td1          : {td1.days}")
print(f"Seconds in td1       : {td1.seconds}")
print(f"Microseconds in td1  : {td1.microseconds}")
