"""
Author : GOVIND
Date   : 05-08-2024
"""
import datetime

now = datetime.datetime.now()
print(f"Current date and time (with microseconds): {now}")
# Attributes (same as date and time)
print(f"Year        : {now.year}")
print(f"Month       : {now.month}")
print(f"Day         : {now.day}")
print(f"Hour        : {now.hour}")
print(f"Minute      : {now.minute}")
print(f"Second      : {now.second}")
print(f"Microsecond : {now.microsecond}")

new_datetime = now.replace(year=2023, month=12, day=25)
print(f"New datetime : {new_datetime}")
