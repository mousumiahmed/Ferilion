"""
Author : GOVIND
Date   : 05-08-2024
"""
"""
18-05-2024
05-18-2024
05/18/2024
18/05/2024
18-05-24
05-18-24
2024-05-18
2024-18-05
"""
# https://www.iso.org/iso-8601-date-and-time-format.html

import datetime
# from datetime import datetime

# Create a date object representing today's date
today = datetime.date.today()
# print("Today's Date  :", today)

# Create a specific date
# specific_date = datetime.date(2000, 1, 1)
# print("Specific Date :", specific_date)
# # print("Specific Date :", type(specific_date))
#
# #
# Get the year, month, and day of the date
# print("Year  :", specific_date.year)
# print("Month :", specific_date.month)
# print("Day   :", specific_date.day)
# print("Day   :", type(specific_date.day))

#
# # # # Get the weekday (0 for Monday, 1 for Tuesday, ..., 6 for Sunday)
# print("Weekday     :", today.weekday())
# # #
# # # # Get the ISO weekday (1 for Monday, 2 for Tuesday, ..., 7 for Sunday)
# print("ISO Weekday :", today.isoweekday())
#
# Format the date as an ISO 8601 string (YYYY-MM-DD)
# print("ISO Format  :", today.isoformat())
# #
# # # Replace year, month, or day with new values
# new_date = today.replace(year=2025)
# print("New Date    :", new_date)
