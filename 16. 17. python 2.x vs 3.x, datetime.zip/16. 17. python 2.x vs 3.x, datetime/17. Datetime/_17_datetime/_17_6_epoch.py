"""
Author : GOVIND
Date   : 05-08-2024
"""

# https://www.epochconverter.io/
import time
import datetime

# Fetch epoch time using time module
epoch_time_1 = time.time()
print("Epoch time (time module)     :", epoch_time_1)

# Fetch epoch time using datetime module
epoch_time_2 = datetime.datetime.now().timestamp()
print("Epoch time (datetime module) :", epoch_time_2)
