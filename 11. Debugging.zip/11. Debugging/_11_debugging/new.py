"""
Author : GOVIND 
Date   : 29-07-2024
"""
"""
debugging:
---------
syntax errors
runtime errors
semantic errors

4 things

project setup
how to run it in local
how to debug it
execution flow

print

pdb 
UI

"""

# from new2 import sample
# def reverse_string(s):
#     # breakpoint()
#     # import pdb; pdb.set_trace()
#     new = ''
#     for each in s:
#         # print(each)
#         new = each + new
#     # new_res = None
#     try:
#         new_res = sample(15, "5")
#
#     except Exception as e:
#         print(e)
#     dc = {"name": "Ramesh", "age":25, "salary": 125632, "location": "bangalore", "is_permanent": True, "fruit": "apple", "fruit2": "Cherrys"}
#     a = 20
#     b = 30
#     c = 40
#     d = 50
#     e = 100
#     f = 10
#     g = 6
#     h = 9
#     i = 2
#     j = 9
#     y1 = new + "hello"
#     # print(new_res)
#     return new, y1, new_res
#
#
# print(reverse_string("p"))

import logging

logging.basicConfig(format='%(asctime)s : %(filename)s  --- %(message)s',
                    handlers=[logging.FileHandler('test.log'), logging.StreamHandler()],
                    level=logging.DEBUG)

x = 10
y = 20
logger = logging.getLogger("MyLogger")
logger.info(f"this is info {x}, {y}")
logger.debug("this is debug")
logger.warning("this is warning")
logger.error("this is error")
logger.critical("this is critical")

"""
INFO
DEBUG
WARNING
ERROR
CRITICAL


"""