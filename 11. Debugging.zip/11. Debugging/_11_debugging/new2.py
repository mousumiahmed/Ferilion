"""
Author : GOVIND 
Date   : 29-07-2024
"""


def sample(x,y):
    # import pdb; pdb.set_trace()
    x = x * 25
    y = y *26
    z = "python"
    res = x + y
    return z
