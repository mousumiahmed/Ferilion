"""
Author : GOVIND 
Date   : 17-07-2024
"""
"""
oop - object oriented programming

encapsulation - binding the data and the methods into a single unit
inheritance
polymorphism
abstraction

class ClassName:
    def __init__(self, attributes):
        pass
    def instance_methods(self):
        pass

attributes
instance variables
instance methods
self -
constructor -


inside the class - instance variables, instance methods, class methods
using the object - instance variables, instance methods, class methods
"""


class Car:
    car_colour = "Blue"
    _prot_clas_var = "protected class var"
    __private_class_var = "private class var"

    def __init__(self, make, model):
        self.make = make
        self.model = model
        self._protected_variable = "protected variable"
        self.__private_variable = "private variable"

    def car_details(self):
        return f"the car details are {self.make}, {self.model}"

    # car_colour = "Blue"

    def car_mileage(self, mileage):
        return f"for the make {self.make} and {self.model} the mileage is {mileage} {Car.car_colour}"

    @classmethod
    def class_method(cls):
        # x = cls.add(10,25)
        return f"class variable {cls.car_colour} {Car.add(10, 25)} {cls.add(10, 25)}"

    def another(self):
        return (f"{self.car_mileage(18)}, {Car.class_method()} {self.class_method()} {self.car_colour} {Car.car_colour}"
                f"{self._protected_variable}, {self.__private_variable}, {self.__private_class_var}, {self._prot_clas_var}"
                f"{self._protected_meth()}, {self.__private_meth()}")

    def _protected_meth(self):
        return self.add(10, 20)

    def __private_meth(self):
        return "from private meth"

    @staticmethod
    def add(n1, n2):
        return n1 + n2


honda = Car("Honda", "Civic")
tata = Car("tata", "Nexon")
#getattr, setattr, delattr, hasattr

# x = getattr(honda, "make", 1985)
# print(x)
# print(honda.make)
# print(honda.make)
# setattr(honda, "year", 1985)
# print(honda.year)
# print(honda.car_details())
# print(honda.make)
# delattr(honda, "make")
# print(honda.car_details())
# print(hasattr(honda, "model"))


# tata = Car("TATA", "Nexon")

# print(honda.class_method())
# print(honda.another())
# print(honda._protected_meth())
# print(honda.add(10, 20))
# print(honda.__private_meth())
# print(honda._protected_variable)
# print(honda._Car__private_variable)
# print(honda.another())
# print(honda.another())
# print(honda.class_method())
# print(honda.make)
# print(tata.model)
# print(tata.car_colour)
# print(honda.car_colour)
# print(honda.car_mileage("18 km/ltr"))
# print(tata.car_mileage("20 km/ltr"))
# print(honda.car_details())
# print(tata.car_details())

# ls = [1,2]
# ls.append()

# def funcone(param1, param2):
#     pass
# def functwo():
#     pass

"""
how to create a class
what is constructor and why it is required
what is self and why it is required
what is instance variables, class variables, instance methods
how to call the instance methods inside the class and after creating the objects
how to fetch the class variables and attributes, instance variable inside the class and after creating the objects
"""