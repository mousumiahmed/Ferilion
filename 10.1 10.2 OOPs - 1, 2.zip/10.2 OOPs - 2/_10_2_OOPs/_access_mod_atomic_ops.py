"""
Author : GOVIND
Date   : 28-06-2024
"""


#
#
# class Person:
#     nationality = "Indian"
#     _prot_class_var = "I am from protected class var"
#     __private_class_var = "I am from private class var"
#
#
#     def __init__(self, name, age):
#         self._protected_varibale = "I am protected variable"
#         self.__private_variable = "i am from private variable"
#         self.name = name
#         self.age = age
#
#     def get_the_data(self):
#         x = self.another_method()
#         y = self._protected_method()
#         z = self.__private_method()
#         return (f"{self.name}, {self.age},{Person.nationality}, {x} , {self._protected_varibale}, "
#                 f"{self.__private_variable}, {y}, {z}")
#
#     def _protected_method(self):
#         return "I am from protected method"
#
#     def __private_method(self):
#         return " I am from private method"
#     def another_method(self):
#         return "i am from another method"
#
#     @staticmethod
#     def add():
#         return f"I am from static method "
#
#     @classmethod
#     def class_meth(cls):
#         return f"{cls.nationality} "
#
#     @property
#     def fun(self):
#         return "I am from fun"
#
#
#
# p1 = Person("Rajesh", 30)
# print(p1.fun)
# print(p1.name)
# # print(p1.class_meth())
# # print(p1.add())
# # print(p1._protected_method())
# # print(p1.__private_method())
# # print(p1._prot_class_var)
# # print(p1.__private_class_var)
# # print(p1)
# # print("accesing class var: ", p1.nationality)
# # print("accessing the attributes: ",p1.name, p1.age)
# # print("accesing the instance methods: ", p1.get_the_data())
# # print("accesing protected var : ", p1._protected_varibale)
# # print("accesing private varibale: ", p1.__private_variable)
#

# class Person:
#
#     def __init__(self, name, age):
#         self.name = name
#         self._age = None
#         self.age = age
#
#     @property
#     def age(self):
#         return self._age
#
#     @age.setter
#     def age(self, value):
#         if not isinstance(value, int):
#             raise ValueError("age must be integer")
#         self._age = value
# try:
#     p1 = Person("ramesh", "30")
# except ValueError as e:
#     print(e)
# print(p1)
# print(p1.age)

# p1 = Person("Ramesh", 3)
# print(p1.name)
# x = getattr(p1, "salary", 1000)
# print(x)
# print(p1.name)
# print(p1.salary)
# setattr(p1, "salary", 1000)
# setattr(p1, "name", "suresh")
# print(p1.name)
# print(p1.salary)

# print(p1.name)
# delattr(p1, "name")
# print(p1.name)

# x = hasattr(p1, "name")
# print(x)

# on class variable
# class MyClass:
#     class_var = 20


# # Get class variable
# print(getattr(MyClass, 'class_var'))
# #
# # # Set class variable
# setattr(MyClass, 'class_var', 30)
# print(MyClass.class_var)
#
# # Delete class variable
# delattr(MyClass, 'class_var')
# print(hasattr(MyClass, 'class_var'))



# class Person:
#
#     def __init__(self, name, age):
#         self.name = name
#         self.age = age
#
#     def __str__(self):
#         return f"the object is created with attributes {self.name} , {self.age}"
#
#
# p1 = Person("ramesh", 30)
# print(p1)
# # str()

class Person:

    def __init__(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs

    def args_kwargs(self):
        return f"*args {self.args}, **kwargs {self.kwargs}"

p1 = Person(20, 3, name="ramesh", age=30)
print(p1.args_kwargs())
print(p1.args)
print(p1.kwargs)