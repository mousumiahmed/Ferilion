"""
Author : GOVIND 
Date   : 14-04-2024
"""
# https://dev.mysql.com/doc/connector-python/en/connector-python-installation-binary.html
# pip install mysql-connector-python

import mysql.connector


def connect_to_mysql(database, username, password, host):
    try:
        conn = mysql.connector.connect(
            database=database,
            user=username,
            password=password,
            host=host
        )
        return conn
    except Exception as e:
        print(f"Error connecting to MySQL: {e}")
        return None


# Function to create database
# def create_database(conn, database_name):
#     try:
#         cursor = conn.cursor()
#         cursor.execute(f"CREATE DATABASE IF NOT EXISTS {database_name}")
#         conn.commit()
#     except mysql.connector.Error as e:
#         print(f"Error creating database: {e}")
#         conn.rollback()
#     finally:
#         cursor.close()
#

# Function to create table
def create_table(conn, table_name, columns):
    try:
        cursor = conn.cursor()
        columns_str = ', '.join(columns)
        cursor.execute(f"CREATE TABLE IF NOT EXISTS {table_name} ({columns_str})")
        print(f"CREATE TABLE IF NOT EXISTS {table_name} ({columns_str})")
        conn.commit()

    except mysql.connector.Error as e:
        print(f"Error creating table: {e}")
        conn.rollback()
    finally:
        cursor.close()


# Function to insert data into table
def insert_data(conn, table_name, data):
    try:
        cursor = conn.cursor()
        placeholders = ', '.join(['%s'] * len(data))
        columns = ', '.join(data.keys())
        values = tuple(data.values())
        print(f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})")
        print("Values-", values)
        cursor.execute(f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})", values)
        print()
        conn.commit()
        cursor.close()

    except mysql.connector.Error as e:
        print(f"Error inserting data: {e}")
        conn.rollback()
    finally:
        conn.close()


# Function to fetch all data from table
def fetch_all_data(conn, table_name):
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute(f"SELECT * FROM {table_name}")
        rows = cursor.fetchall()
        cursor.close()
        return rows
    except mysql.connector.Error as e:
        print(f"Error fetching data: {e}")
    finally:
        conn.close()


# Function to fetch one data from table based on primary key
def fetch_one_data(conn, table_name, primary_key_value):
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute(f"SELECT * FROM {table_name} WHERE id = %s", (primary_key_value,))
        row = cursor.fetchone()
        cursor.close()

        return row
    except mysql.connector.Error as e:
        print(f"Error fetching data: {e}")
    finally:
        conn.close()


# Function to fetch some data from table based on condition
def fetch_some_data(conn, table_name, condition):
    try:
        cursor = conn.cursor(dictionary=True)
        cursor.execute(f"SELECT * FROM {table_name} WHERE {condition}")
        rows = cursor.fetchall()
        cursor.close()

        return rows

    except mysql.connector.Error as e:
        print(f"Error fetching data: {e}")
    finally:
        conn.close()


# Function to update one data in table based on primary key
def update_one_data(conn, table_name, primary_key_value, new_data):
    try:
        cursor = conn.cursor()
        new_data_values = ', '.join([f"{key} = %s" for key in new_data.keys()])
        values = tuple(list(new_data.values()) + [primary_key_value])
        cursor.execute(f"UPDATE {table_name} SET {new_data_values} WHERE id = %s", values)
        conn.commit()
        cursor.close()

    except mysql.connector.Error as e:
        print(f"Error updating data: {e}")
        conn.rollback()
    finally:
        conn.close()


# Function to update all data in table
def update_all_data(conn, table_name, new_data):
    try:
        cursor = conn.cursor()
        new_data_values = ', '.join([f"{key} = %s" for key in new_data.keys()])
        values = tuple(new_data.values())
        cursor.execute(f"UPDATE {table_name} SET {new_data_values}", values)
        conn.commit()
        cursor.close()

    except mysql.connector.Error as e:
        print(f"Error updating data: {e}")
        conn.rollback()
    finally:
        conn.close()


# Function to update some data in table based on condition
def update_some_data(conn, table_name, new_data, condition):
    try:
        cursor = conn.cursor()
        new_data_values = ', '.join([f"{key} = %s" for key in new_data.keys()])
        values = tuple(list(new_data.values()) + condition)
        cursor.execute(f"UPDATE {table_name} SET {new_data_values} WHERE {condition[0]} = %s", values)
        conn.commit()
        cursor.close()

    except mysql.connector.Error as e:
        print(f"Error updating data: {e}")
        conn.rollback()
    finally:
        conn.close()


# Function to delete one data from table based on primary key
def delete_one_data(conn, table_name, primary_key_value):
    try:
        cursor = conn.cursor()
        cursor.execute(f"DELETE FROM {table_name} WHERE id = %s", (primary_key_value,))
        conn.commit()
        cursor.close()

    except mysql.connector.Error as e:
        print(f"Error deleting data: {e}")
        conn.rollback()
    finally:
        conn.close()


# Function to delete all data from table
def delete_all_data(conn, table_name):
    try:
        cursor = conn.cursor()
        cursor.execute(f"DELETE FROM {table_name}")
        conn.commit()
        cursor.close()

    except mysql.connector.Error as e:
        print(f"Error deleting data: {e}")
        conn.rollback()
    finally:
        conn.close()


# Function to delete some data from table based on condition
def delete_some_data(conn, table_name, condition):
    try:
        cursor = conn.cursor()
        cursor.execute(f"DELETE FROM {table_name} WHERE {condition[0]} = %s", condition[1])
        conn.commit()
    except mysql.connector.Error as e:
        print(f"Error deleting data: {e}")
        conn.rollback()
    finally:
        conn.close()


# Example usage:
if __name__ == '__main__':
    # Connect to MySQL database
    conn = connect_to_mysql(database='testdatabase', username='root', password='admin1234', host='localhost')


    # Create table if not exists
    create_table(conn, 'user', ['id INT AUTO_INCREMENT PRIMARY KEY', 'name VARCHAR(255)', 'email VARCHAR(255)'])
    #
    # # Insert data into table
    # insert_data(conn, 'users', {'name': 'Ramesh', 'email': 'ramesh@email.com'})
    #
    # # Fetch all data from table
    # print(fetch_all_data(conn, 'users'))
    #
    # # Fetch one data from table based on primary key
    # print(fetch_one_data(conn, 'users', 1))
    #
    # # Fetch some data from table based on condition
    # print(fetch_some_data(conn, 'users', 'name = "John Doe"'))
    #
    # # Update one data in table based on primary key
    # update_one_data(conn, 'users', 1, {'email': 'john.doe@example.com'})
    #
    # # Update all data in table
    # update_all_data(conn, 'users', {'email': 'john@example.com'})
    #
    # # Update some data in table based on condition
    # update_some_data(conn, 'users', {'email': 'john@example.com'}, ('name', 'John Doe'))
    #
    # # Delete one data from table based on primary key
    # delete_one_data(conn, 'users', 1)
    #
    # # Delete all data from table
    # delete_all_data(conn, 'users')
    #
    # # Delete some data from table based on condition
    # delete_some_data(conn, 'users', ('name', 'John Doe'))

