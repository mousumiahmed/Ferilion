"""
Author : GOVIND
Date   : 10-08-2024
"""
# https://dev.mysql.com/doc/connector-python/en/connector-python-installation-binary.html
# pip install mysql-connector-python

"""
SQLALCHEMY - ORM - pip install mysqlclient

raw sql queries ->

ORM -> object relational mapping ->

class Table(inherit):
    id = Column()

raw sql queries ->

pip install 

conn = 
cursor = conn.cursor()
cursor.execute(query, values)
CREATE   - INSERT   - one, many, all
UPDATE   - UPDATE   - one, many, all
DELETE   - DELETE   - one, many, all

conn.commit()
cursor.close()
conn.close()

conn = 
cursor = conn.cursor()
cursor.execute(query, values)
RETRIEVE - FETCHING - one, many, all
cursor.close()
conn.close()
"""

import mysql.connector

conn = mysql.connector.connect(user='root',
                               password='admin1234',
                               host='localhost',
                               # port=3306,
                               database='student')


# cursor = conn.cursor()
# query = 'CREATE TABLE IF NOT EXISTS usertable (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(50), email VARCHAR(50))'
# cursor.execute(query)
#
# cursor.close()
# # print("success")
# conn.close()
# print("closed the connection")

'INSERT - commit'
# cursor = conn.cursor()
# query = 'INSERT INTO usertable (name, email) VALUES (%s, %s)'
# # values = ("ramesh", "ramesh@email.com")
# # cursor.execute(query, values)
# values = [("ramesh2", "ramesh@email.com"),
#           ("ramesh3", "ramesh@email.com"),
#           ("ramesh4", "ramesh@email.com"),
#           ("ramesh5", "ramesh@email.com")]
# cursor.executemany(query, values)
# conn.commit()
# cursor.close()
# conn.close()
# print("closed the connection")

'UPDATE - commit'
# cursor = conn.cursor()
# query = 'UPDATE usertable SET name = %s WHERE id = %s'
# values = ("suresh", 2)
# cursor.execute(query, values)
# conn.commit()
# cursor.close()
# conn.close()
# print("closed the connection")


'DELETE - commit'
# cursor = conn.cursor()
# query = 'DELETE FROM usertable WHERE id = %s'
# values = (5,)
# cursor.execute(query, values)
# conn.commit()
# cursor.close()
# conn.close()
# print("closed the connection")

'RETRIEVE '
# cursor = conn.cursor(dictionary=True)
# query = 'SELECT * FROM usertable WHERE id = %s'
# values = (3,)
# cursor.execute(query, values)
# res = cursor.fetchone()
# print(res, type(res))
# cursor.close()
# conn.close()
# print("closed the connection")
# cursor = conn.cursor(dictionary=True)
# query = 'SELECT * FROM usertable'
# cursor.execute(query)
# res = cursor.fetchall()
# print(res, type(res))
# cursor.close()
# conn.close()
# print("closed the connection")

