"""
Author : GOVIND
Date   : 05-07-2024
"""

"""
dictionary:
-----------
-> mutable
-> ordered (3.7+)
-> key, value pairs
-> keys   - unique - immutable
-> values - any dt/ds 
-> {}
-> 11
-> min, max - keys - homogenous data
-> len
-> in
 
dict comprehensions
dict conversions

"""
# dc = {"name": "Rajesh", "age": 30, "salary": 1000.5}

# print(max(dc))
# print(min(dc))
# print("Rajesh" in dc)
# print(dc)
# print(len(dc))

# for each in dc:
#     print(each)

# print(dir(dict))
dc_meth = ['clear', 'copy', 'fromkeys', 'get', 'items', 'keys', 'pop',
           'popitem', 'setdefault', 'update', 'values']

'items() keys() values()'

# dc = {"name": "Rajesh", "age": 30, "salary": 1000.5}

# items = dc.items()
# print(items, type(items))
# for each in dc.items():
#     print(each)

# for keys, values in dc.items():
#     # print(f"key is {keys} and value is {values}")
#     print(keys, type(keys))
#     print(values, "\n")

# ('salary', 1000.5)

# x = [('name', 'Rajesh', 3), ('age', 30, 4), ('salary', 1000.5, 5)]
# for p, q, r in x:
#     print(p, q, r)

# keys = dc.keys()
# print(keys, type(keys))
# for each in dc.keys():
#     print(each)

# vals = dc.values()
# print(vals, type(vals))
# for each in dc.values():
#     print(each)

'pop, popitem, clear'

# dc.popitem()
# print(dc)
# dc.pop("age")
# print(dc)

'fromkeys'
# ls = ["a", "b", "c"]
# x = dict.fromkeys({"name":20, "age":30}, 100)
# print(x)

'update'
# dc1 = {"a": 10, "b":20}
# # dc = {"name": "Rajesh", "age": 30, "salary": 1000.5}
# ls = [("new", 20), ("hi", 40)]
# dc1.update(ls)
# print(dc1)

'setdefault'
# dc = {"name": "Rajesh", "age": 30, "salary": 1000.5}
# dc.setdefault("name", "suresh")
# print(dc)

# dc = {"name": "Rajesh", "age": 30, "salary": 1000.5}

# y = dc["location"]
# print(y)

# x = dc.get("location", "bangalore")
# print(x)
# print(dc)

# dc = {"name": "Rajesh", "age": 30, "salary": 1000.5}
# c = {}
# c["name"] = "Suresh"
# print(c)

'dict comprehension'
# {key expression: value expression for items in iterables if condition optional}

# dc = {x:x**2 for x in range(5)}
# ls = ["a", "b", "c", "d"]
# n = [100, 200,300]
# dc = {k: v for k, v in zip(ls,n)}
# print(dc)

'dict conversions - dict()'
# dict()
ls = ["a", "b", "c", "d"]
n = [100, 200,300]

# s = zip(ls, n)
# print(s, type(s))
# y = dict(s)
# print(y)

ls1 = [(10, 20), [30, 40], (50,6)]
y = dict(ls1)
print(y)

# collections module
# sum, any, all


"""
setdefault -> if key is not present it will get added to dict, 
              if key is present it won't affect the dict
.get()     -> if key is not present it will return None(no error) 
              if you pass value also it won't affect the dict            
dc[key]    -> if key is not present, it will throw an error
              if key is present, it will fetch the value of that key 
              
dc[key] = value -> if key is not present it will added to the dict
                   if key is present it will replace
"""
