"""
Author : GOVIND
Date   : 04-07-2024
"""
"""
req:
----
state - dt/ds - input output
behavior - B.L - CRUD - DM LOOPS OPERATORS

mutable   : list, set, dictionary
immutable : int, float, complex, bool, string, tuple

iterables: string, list, set, tuple, dictionary, range

sequence type: string, list, tuple

sequence ops:
-------------
Indexing - positive negative
Slicing -
concatenating - with the same sequence type
multiply - with integers
min - homogenous data
max - homogenous data
len -
in 


set:
----
-> mutable
-> unordered
-> unique elements
-> elements - immutable 
-> {} - empty set - set() - set({})
-> 17
-> min, max - homogenous data
-> len
-> in

set comprehensions

set conversions

"""

# st = {1, 2.3, 4+5j, True, "python",  (4, 5), None}
# print(st)
# print(None in st)
# print(len(st))
# st = {"python", "Rajesh", "Programming"}
# print(max(st))
# print(min(st))

# unhashable type list, set, dictionary - mutable

"""
set
st = {1, 2, 3, 1, 2, 2}

hash table
-----------

elements        hash value
---------       ------------
    1               iosugd
    2               isbdbcui
    3               uoibcb#$

"""

# print(dir(set))
set_meth = ['add', 'clear', 'copy', 'difference', 'difference_update',
            'discard', 'intersection', 'intersection_update', 'isdisjoint',
            'issubset', 'issuperset', 'pop', 'remove', 'symmetric_difference',
            'symmetric_difference_update', 'union', 'update']

# print(len(set_meth))
"""
isdisjoint, issubset, issuperset
add    - add
remove - clear, discard, pop, remove

union   intersection          difference         symmetric_difference
update  intersection_update   difference_update  symmetric_difference_update
"""
st1 = {"a","b","c","d"}
# for each in st1:
#     print(each)
# st2 = {6, 3, 4, 5}
#
# st3 = st1.union(st2)
# print(st3)
# st1.update(st2)
# print(st1)

# st2.add("new")
# print(st2)

# y = st1.pop()
# print(st1)
# print(y)

# st1.clear()
# print(st1)

# discard, remove

# y = st1.discard("python")
# print(st1)
# print(y)
# st1.remove("world")
# print(st1)

# set comprehensions

# {expression for item in iterable if condition(optional)}
# y = {x**2 for x in range(10)}
# print(y)

# set conversions - set(iterables)

# ls = [1, 2, 3, 4, 5, ["a", 1]]
# y = set(ls)
# print(y)

