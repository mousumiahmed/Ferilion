"""
Author : GOVIND 
Date   : 08-07-2024
"""
"""
functions:
----------
procedural - input()
functional - 
oop

def keyword - function name(identifiers) - (parameters(optional)):
    block of code
    
another line


f(x) = 2x + 3

def f(x):
    res = 2*x + 3
    print(res)

functions - outside the class
methods   - inside the class - object is involved - .

params : while defining the function we will pass the variables 
args   : while calling the function we are passing the values

print  : 
return : 

default args    : creating the function
params without default followed by default args

positional args : calling the function params order is preserved
keyword args   : calling the function using param names provide the values -> param_name = value

positional args followed by keyword args

*args
**kwargs

"""
# n1 = int(input("enter num1"))
# n2 = int(input("enter num2"))
# res = n1 + n2
# print(res)

# User-defined Functions:
# using return
def add_numbers(x, y):
    return x + y


print("\nadd_numbers return type: ", add_numbers(3, 5))
print("\n****************************************************************************\n")


# using print
def add_nums(x, y):
    print(x + y)


print("add_numbers print type: ")
add_nums(3, 5)
print("\n****************************************************************************\n")

# Built-in Functions:
result = len("Hello, World!")
print("\n Builtin method len : ", result)

print("\n****************************************************************************\n")

# def add_two_int(n1, n2):
#     ls = [1, 2, 3]
#     res = n1 + n2
#     # return res
#     # print(res)
#     # print(n1)
#     # print(n2)
#     return(res)
    # return(n1)
    # return(n2)

# print(id(add_two_int))
# add_two_int(10, 2)
# x = add_two_int(10, 2)
# print(x)

# def another_func():
#     x = add_two_int(10, 20)
#     print(f"x value is {x}")
#
# another_func()

# def func1():
#     print("entering func1")
#     func2()
#     print("exiting from func1")
#
# def func2():
#     print("entering func2")
#     func3()
#     print("exiting from func2")
#
# def func3():
#     print("entering func3")
#     print("exiting from func3")
#
# func1()

# def add_two_int(n1, n2=9):
#     res = n1 + n2
#     return res, n1, n2
#
# x,y,z= add_two_int(5, 20)
# print(x)
# print(y)
# print(z)

# p, q, r = 2, 5, 7
# print(p)
# print(q)
# print(r)

# for _ in range(5):
#     print("hi")

# def emp_data(name, age=35 ):
#     res = f"my name is {name} and age is {age}"
#     return res
#
# x= emp_data("Rajesh", age=50, )
# print(x)
# print(y)
# print(z)

# def func(*args, n2=99):
#     sum = 0
#     for each in args:
#         sum += each
#     return sum, args, n2
#
# print(func(5, 7, 8, 5))

# def functwo(n2, **kwargs):
#     # return kwargs, type(kwargs)
#     return kwargs, n2
#
#
# y = functwo(1000, name="Ramesh", age=25, )
# print(y)

# def func2(n1=5, n2=10):
#     return n1+n2
# print(func2())
# (2, (2,))

def func(*args):
    sum = 0
    # ls = []
    for each in args:
        if isinstance(each, (int, float)):
            sum += each

    return(sum)


print(func(5, 7.5, 8, 5, "python"))
