"""
Author : GOVIND 
Date   : 02-07-2024
"""
"""
req:
----
state - dt/ds - input output
behavior - B.L - CRUD - DM LOOPS OPERATORS

mutable    : list, set, dictionary
immutable  : int, float, complex, string, bool, tuple

sequence type : string, list, tuple

iterables     : list, string, tuple, set, dictionary, range - iter

loops
-----
who ever are present in b13 i am going to 1000 rupees

for
  
iter
next

StopIteration


while
when we don't know the number of iterations before hand

condition based iteration
--------------------------

value - initialize variable
while condition:
    action part 
    increment/decrement the value to reach the condition

y = 0
while y < 10:
#     action part
    y += 1



unknown iteration count
-----------------------
while True:
    # action part
    if condition:
        break
        
"""
# ls = [11, 22, 33, 44]

# a = 11
# b = 22
# c = 33
# d = 44

# for each in ls:
#     print(each)

# dc = {"name": "rajesh", "age":25, "salary": 25000}

# for each in dc:
#     print(each, end=' ')

# s = "python"
# for each in s:
#     print(each)

# print("**** for loop iteration of range ******")
# for num in range(5):
#     print(num)
# print("****end of the program******")


# print("**** for loop iteration of list******")
# lst = [1, 2, 2, 3, 4]
# for each in lst:
#     print(each)
#
# print("****end of the program******")
#
# print("**** for loop iteration of tuple ******")
# tple = (1, 5, 7, 9)
# (print("without index"))
# for each in tple:
#     print(each)
#
# (print("with index"))
# for i in range(len(tple)): # for i in range(4)
#     print(tple[i])
# print("****end of the program******")

# print("**** for loop iteration of string ******")
#
# st = "Python"
# for each in st:
#     print(each)
#
# print("**** for loop iteration of dictionary ******")
#
# dct = {"key1": "val1", "key2": "val2", "key3": "val3"}
#
# for each in dct:
#     print(each)
#
# St = {1, 2, 3, 4, 5}
#
# for each in St:
#     print(each)


# print("**** break continue pass****")


# b13 = ["rohit", "axar", "pandya", "kohli", "jadeja", "surya"]

# for each in b13:
#     print("give 1000 rs to ", each)

# for each in b13:
#     # print("give 1000 rs to ", each) # action part
#     if each == 'pandya':
#         print("give 1000 rs to ", each)  # action part
#         break
#     # print("give 1000 rs to ", each) # action part

# for each in b13:
#     # print("give 1000 rs to ", each) # action part
#     if each == "pandya":
#         print("give 1000 rs to ", each)  # action part
#         continue
#     # print("give 1000 rs to ", each) # action part
#     # print("hello")

# for each in b13:
#     pass
# def function():
#     pass

# y = 0
# while y < 10:
#     y += 1
#     print("hello", y)

# factorial - 5 - 5*4*3*2*1
# 5 * (5-1) * (4-1) * (3-1) *(2-1) *

# n = int(input("enter a number : "))

# first loop n = 5, res = 1,  -> res = 1 * 5 = 5,   n = 5 - 1 = 4
# secnd loop n = 4, res = 5,  -> res = 5 * 4 = 20,  n = 4 - 1 = 3
# third loop n = 3, res = 20, -> res = 20 * 3 = 60, n = 3 - 1 = 2
# forth loop n = 2, res = 60, -> res = 60 * 2 = 120, n = 2 - 1 = 1
#  n = 1, res = 120, res = 120 * 1, n = 0
# fifth loop - it won't enter as condition is not met

# res = 1
# while n > 1:
#     res *= n
#     n -= 1
# print(res)
# count = 0
# while True:
#     count+=1
#     print(count)
#     if count == 20:
#         break
# print(count)

# secret_num = 3
# # guess = int(input("enter a number b/w 0-9: "))
# # if guess == secret_num:
# #     print("Congratulation you have guessed it correctly")
# #
# # else:
# #     print("try again")
#
# while True:
#     guess = int(input("enter a number b/w 0-9: "))
#     if guess == secret_num:
#         print("Congratulation you have guessed it correctly")
#         break
#     else:
#         print("try again")

# ls = [11, 22, 33, 55, 44, 66, 77]
ls = eval(input("enter a list []: "))
# req: if 33 is present yes number found if it is not present number not found
num_to_find = int(input("enter the number to find: "))

for each in ls:
    # print(each)
    if each == num_to_find:
        print("num is found")
        break
else:
    print("num not found")

# print("**** nested for loop ******")

# nums = [11, 22, 33, 44]
# fruits = ["apple", "kiwi", "cherrys", "banana"]
# city = ["bangalore", "chennai", "hyderabad"]
#
# for each in nums:
#     print(each)
#     for i in fruits:
#         print("    ", i)
#         for j in city:
#             print("        ", j)
