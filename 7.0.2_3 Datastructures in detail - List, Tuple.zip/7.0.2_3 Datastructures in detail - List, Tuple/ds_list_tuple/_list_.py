"""
Author : GOVIND 
Date   : 04-07-2024
"""
"""
Req:
---
state - dt/ds - input output
behavior - B.L - CRUD - DM LOOPS OPERATORS

mutable    : list, set, dictionary
immutable  : int, float, complex, bool, string, tuple

iterables - string, list, tuple, set, dictionary, range

sequence type: string, list, tuple


list:
------
-> mutable - CRUD
-> ordered, sequence type
-> any kind of dt/ds
-> homogenous, hetrogenous
-> []
-> 11

sequence type:
-------------
Indexing - positive - negative
Slicing
concatenating - with the list only
multiply      - with integer only
min - homogenous
max - homogenous
len -
in  - 

list comprehension

list conversions - list()
"""
#    -10 -9   -8      -7    -6      -5      -4      -3      -2              -1
# ls = [1, 2.3, 4+5j, True, None, "python", [1,2], (1,2,3), {11,22}, {"name":"Rajesh", "Age":25}]
# ls2 = ["a", "b", "c"]
#     0   1    2      3    4        5       6       7       8               9
# print(ls, type(ls))
# print(ls[0])  # first element
# print(ls[-1]) # last element
# print(ls[2: 6])
# print(ls[-7: -2])
# print(ls[-7: 8])
# print(ls[1:9:3])
# print(ls[8: 2: -1])
# print(ls[::-1])
# print(ls[:5])
# print(ls[5:])

# con = ls2 + ls
# print(con)

# mul = ls2 * 5
# print(mul)

# print(1 in ls)
# print("py" in ls)
# print(len(ls))
# ls = [[1, 20], [20, 1], [0, 25]]
# print(max(ls))
# print(min(ls))
ls = [1, 2.3, 4+5j, True, None, "python", [1,2], (1,2,3), {11,22}, {"name":"Rajesh", "Age":25}]
# ls.count()
# print(ls[0])

# for each in ls:
#     print(each)

# for each in range(len(ls)):
#     print(ls[each])

# print(dir(list))
list_meth = ['append', 'clear', 'copy', 'count', 'extend', 'index', 'insert',
             'pop', 'remove', 'reverse', 'sort']

"""
add    - append, insert, extend 
remove - pop, remove, clear

copy, count, index, reverse, sort

"""

# ls = [1, 2.3, 4+5j, True, None, "python", [1,2], (1,2,3), {11,22}, {"name":"Rajesh", "Age":25}]
# print(id(ls))
# ls.append("new")
# ls.insert(2, "new")
# ls.extend({"a": 20, "b": 30, "c":40})
# print(ls)
# print(id(ls))
# remove - pop, remove, clear
# y = ls.pop(2)
# print(y)
# ls.remove("a")
# ls.clear()
# print(ls)

'count, index, reverse'
# ls = [1, 2, 3,  1, 2, 1, 2]
#     0  1   2  3  4  5 6
# y = ls.count(1)
# print(y)
# y = ls.index(1, 2, 5)
# print(y)
# ls.reverse()
# print(ls)

# ls = [22, 11, 0, 5, 6, 9, 87, 6, 3]
# ls.sort()
# print(ls)
# ls = [22, 11, 0, 5, 6, 9, 87, 6, 3]
# x = sorted(ls)
# print(x)
# print(ls)
# [0, 3, 5, 6, 6, 9, 11, 22, 87]
# [0, 3, 5, 6, 6, 9, 11, 22, 87]

# ls = [1, 2.3, 4+5j, True, None, "python", [1,2], (1,2,3), {11,22}, {"name":"Rajesh", "Age":25}]
# print(ls[5])
# ls[5] = "new value"
# print(ls)
# ls = []
# ls.insert(100, 10)
# # ls[0] = 100
# print(ls)

# list comprehension
# [expression for item in iterable if condition(optional)]
# ls = [2, 4, 5, 9, 11, 7, 8,6]
# new_ls = [x for x in ls if x%2==0]
# print(new_ls)
# new_ls = [x**2 for x in range(10) if x%2==0]
# print(new_ls)

# list conversions - list()
# s = "python"
# n = list(s)
# print(n)

