"""
Author : GOVIND
Date   : 04-07-2024
"""

"""
Tuple:
------
-> immutable - CRD
-> ordered, sequence type
-> any kind of dt/ds
-> homogenous, heterogeneous
-> ()
-> 2
-> empty tuple - ()
-> single element tuple - (obj,)

sequence type:
-------------
Indexing - positive - negative
Slicing
concatenating - with the Tuple only
multiply      - with integer only
min - homogenous
max - homogenous
len -
in  - 

tuple conversions - tuple()

"""

# tp = (1, 2.3, 4+5j, True, None, "python", [1,2], (1,2,3), {11,22}, {"name":"Rajesh", "Age":25})
# print(tp)
# em = ()
# si = (2,)
# print(type(em), type(si))

# print(dir(tuple))
# tp_meth = ['count', 'index']
import sys
# tp = (1, 2, 3, ["a","b", "c"])
# print(sys.getsizeof(tp))
# # print(id(tp))
# tp[-1].append("new")
# # print(id(tp))
# print(tp)
# print(sys.getsizeof(tp))

ls1 = ["a","b"]
print(sys.getsizeof(ls1))
# ls1.append(100)
tp = ("a", "b")
print(sys.getsizeof(tp))








