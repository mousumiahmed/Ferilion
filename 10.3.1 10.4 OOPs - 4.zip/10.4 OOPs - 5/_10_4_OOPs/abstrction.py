"""
Author : GOVIND
Date   : 22-07-2024
"""
"""
abstraction:
focuses on functionality rather than the implementation
ABC
class Common(ABC):
    @abstarctmethod
    def login(self):
        pass

class  - Transactions(Common)
class  - Banking(Common)

"""
from abc import ABC, abstractmethod


class Vehicle(ABC):
    def __init__(self, name):
        self.name = name

    @abstractmethod
    def move(self):
        pass



class Car(Vehicle):
    def move(self):
        return f"{self.name} is driving."


class Plane(Vehicle):
    def move(self):
        return f"{self.name} is flying."


car = Car("Toyota")
print(car.move())

plane = Plane("Boeing")
print(plane.move())
"""
In this example:
- Vehicle is an abstract base class with an abstract method move().
- Car and Plane are concrete subclasses of Vehicle that provide 
  specific implementations for the move() method.
- Abstraction allows us to treat Car and Plane objects uniformly based on 
  their common interface (move()), while hiding the implementation details 
  specific to each class.
"""
