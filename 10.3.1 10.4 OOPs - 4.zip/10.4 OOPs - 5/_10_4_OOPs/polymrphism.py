"""
Author : GOVIND
Date   : 22-07-2024
"""
#
#
# # Method Overriding Polymorphism:
# class Animal:
#     def sound(self):
#         return "Animal makes sound"
#
# class Dog(Animal):
#     # def sound(self):
#     #     return "Dog barks"
#     pass
# class Cat(Animal):
#     def sound(self):
#         return "Cat meows"
#
# ani_obj = Animal()
# print(ani_obj.sound())
# dog_obj = Dog()
# print(dog_obj.sound())
# cat_obj = Cat()
# print(cat_obj.sound())


# Method Overloading
#
# def calculate_area(length, width=1):  # Default width argument
#     return length * width
#
#
# # Calling with two arguments
# area_rectangle = calculate_area(5, 3)
# print(area_rectangle)
#
# # Calling with one argument (default width used)
# area_square = calculate_area(4)
# print(area_square)

# Constructor Overloading
# class Person:
#     def __init__(self, name, age=18):
#         self.name = name
#         self.age = age
#
#     def user_data(self):
#         return f"user name is {self.name} and age is {self.age}"
#
# p_obj = Person("Rajesh")
# print(p_obj.user_data())
# p2_obj = Person("Suresh", 25)
# print(p2_obj.user_data())

# using *args and **kwargs

class Product:
    def __init__(self, name, *args, **kwargs):
        self.name = name
        self.args = args
        self.kwargs = kwargs
    def some(self):
        return self.kwargs

# Creating objects with varying arguments
product1 = Product("Book")
product2 = Product("Laptop", 15, "silver", brand="Dell")

# class Person:
#     def __init__(self, *args, **kwargs):
#         self.args = args
#         self.kwargs = kwargs
#
#     def user_args(self):
#         x = self.args
#         count = 0
#         for each in x:
#             count+=each
#         return count
#
#     def user_kwargs(self):
#         return self.kwargs

# obj1 = Person()
# print(obj1)
# obj2 = Person(10, 2, 3, 9, 11)
# print(obj2.user_args())

# obj3 = Person(name="rajesh", age=25, location="bangalore")
# print(obj3.user_kwargs())
# obj4 = Person(25, 35, salary=1000, is_perm=True)
# print(obj4.user_args())
# print(obj4.user_kwargs())
