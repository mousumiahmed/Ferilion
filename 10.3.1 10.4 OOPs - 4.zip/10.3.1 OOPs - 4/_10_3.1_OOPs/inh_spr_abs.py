"""
Author : GOVIND 
Date   : 22-07-2024
"""

#
# class AnotherParentclass:
#     def __init__(self, ins):
#         self.ins = ins
#
#     def an_ins(self):
#         return f"from AnotherParentclass {self.ins}"
#

class ParentClass:
    parent_class_variable = "parent class variable"

    def __init__(self, parent_instance_variable):
        super().__init__(parent_instance_variable)

        self.parent_instance_variable = parent_instance_variable
        self._protected_variable_parent = "parent protected variable"
        self.__private_variable_parent = "parent private variable"

    def instance_method_parent(self):
        return f"parent instance method {self.parent_instance_variable}"

    def get_protected_variable_parent(self):
        return self._protected_variable_parent

    def _protected_method_parent(self):
        return "parent protected method"

    def __private_method_parent(self):
        return "parent private method"

    @classmethod
    def class_method_example_parent(cls):
        print("parent class method using @classmethod")

    @staticmethod
    def static_method_example_parent():
        print("parent static method using @staticmethod")


class ChildClass(ParentClass, AnotherParentclass):
    def __init__(self, child_inst_var):
        super().__init__("direct value")
        self.child_inst_var = child_inst_var

    def instance_method_parent(self):
        return "from child class"

    def child_inst_method(self):
        # return super().instance_method_parent()
        return super().an_ins()
        # return self.ins


ch_obj = ChildClass("child class instance varibale")
print(ch_obj.child_inst_method())

# polymorphisms

# class Employee:
#     def __init__(self, id=10, *args, **kwargs):
#         self.id = id
#         self.args = args
#         self.kwargs = kwargs
#
#     def inst(self, var=100):
#         return f"{var}"


# emp = Employee()
# print(emp)
# print(emp.inst(10000))
# emp2 = Employee(10, 20)
# print(emp2)
# emp3 = Employee(25, 35, name="Ramesh")
# print(emp3)

# class A:
#     def ins(self):
#         return f"from class A"
#
# class B:
#     def ins(self):
#         return f"from class B"
# class C(B, A):
#     def ins(self):
#         return f"from class C"
#
#
# a = A()
# print(a.ins())
# b = B()
# print(b.ins())
# c= C()
# print(c.ins())

# x = 10
# print(x.__add__(5))
#
# y = "python"
# print(y.__add__("world"))
#

# class OperOverloading:
#     def __init__(self, value):
#         self.value = value
#
#     def __mul__(self, other):
#         return self.value - other.value
#
# x = OperOverloading(5)
# y = OperOverloading(10)
# print(x * y)
#
# a = 10
# b = 20
# print( a * b)

# # __new__, __init__
#
# class Employee:
#     def __init__(self, name, age):
#         self.name = name
#         self.age = age
#
#     def __str__(self):
#         return f"{self.name}, {self.age}"
#
#     def __repr__(self):
#         return f"Employee(name={self.name}, age={self.age})"
#     # def inst(self, var=100):
#     #     return f"{var}"
# emp = Employee("Ramesh", 25)
# print(emp)


"Abstarction"
# what needs to be implemented, how it is implemented


from abc import ABC, abstractmethod


# class Employee(ABC):
#     @abstractmethod
#     def employee_data(self):
#         pass
#     @abstractmethod
#     def dummy_data(self):
#         pass
#
#
# class AnotherClass(Employee):
#
#     def another_meth(self):
#         return "from Another class"
#     def employee_data(self):
#         return "something"
#
#
# obj = AnotherClass()
# print(obj.another_meth())


"""
class A:
    def fun():
        return "from fun"

a = A()
x = a.fun()
print(x)


"""
class A:
    @staticmethod
    def fun():
        return "from fun"

a = A()
x = a.fun()
print(x)
