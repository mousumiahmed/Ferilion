"""
Author : GOVIND 
Date   : 22-07-2024
"""


class A():
    def meth(self):
        print("class A")
        super().meth()
        print("class A.1")


# a_obj = A()
# print(a_obj.meth())

class B():
    def meth(self):
        print("class B")
        super().meth()
        print("class B.1")



#
class C():
    def meth(self):
        print("class C")
        print("class C.1")

        # super().meth()


class X(A, B):
    def meth(self):
        print("class x")
        super().meth()
        print("class x.1")



class Y(B, C):
    def meth(self):
        print("class Y")

        super().meth()
        print("class y.1")



class P(X, Y, C):
    def meth(self):
        print("class P")
        super().meth()
        print("class p.1")



p = P()
p.meth()
# print(P.mro())
"""
[<class '__main__.P'>, <class '__main__.X'>, <class '__main__.A'>, <class '__main__.Y'>, 
<class '__main__.B'>, <class '__main__.C'>, <class 'object'>]
"""