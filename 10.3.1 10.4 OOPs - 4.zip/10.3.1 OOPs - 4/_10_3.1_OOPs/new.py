"""
Author : GOVIND 
Date   : 19-07-2024
"""
"""
mro - method resolution order

"""


#
#
# class Amazon:
#
#     def add_student(self):
#         return "from Amazon"
#
#     def another(self):
#         return "from amazon another"
#
#
# class Flipkart:
#     def __init__(self, school_name):
#         self.school_name = school_name
#
#     def add_student(self):
#         return f"from school {self.school_name}"
#
#
# class Student(Flipkart):
#     def __init__(self, *):
#         super().__init__(*args, **kwargs)
#
#     # def add_student(self):
#     #     return "from class Student"
#     def some(self):
#         # fli_obj = Flipkart("Flipkart")
#         # return fli_obj.add_student()
#         return super().another()
#
#
# stu_obj = Student("New School")
# print(stu_obj.some())
# # amz = Amazon()
# # print(Amazon().add_student())

# class Employee:
#     def __init__(self,companyname="KATTA", *args, **kwargs):
#         self.company_name = None
#         self.somrthing = None
#
#         self.args = args
#         self.kwargs = kwargs
#
#     def emp_details(self, name="Ramesh"):
#         return f"{name}"


# emp = Employee(1, "Ramesh", location="Bangalore", salary=10000)
# emp2 = Employee(2, name="Rajesh")
# emp3 = Employee("new")
# emp4 = Employee("another",id=1, name="Suresh")
# print(emp.emp_details())
# print(emp.emp_details("Suresh"))
#
# # print(emp2)
# # print(emp3)
# # print(emp4)
#
# class A:
#     def meth(self):
#         return "from class A"
# class B(A):
#     def meth(self):
#         return "from class B"
#
# class C(A):
#     def meth(self):
#         return "from class C"
#
# a_obj = A()
# b_obj = B()
# c_obj = C()
#
# print(a_obj.meth())
# print(b_obj.meth())
# print(c_obj.meth())

class Employee:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def emp_details(self):
        return f"emp details are {self.name}, {self.age}"

    # def __str__(self):
    #     return f"{self.name}, {self.age}"
    #
    # def __repr__(self):
    #     return f"Employee({self.name}, {self.age})"


# emp = Employee("ramesh", 35)
# print(emp)

# <__main__.Employee object at 0x000001BAC4C733E0>
# ramesh, 35

# # x = 10
# # print(x.__add__(5))
# # y = "hi"
# # print(y.__add__(" hello"))
#
class AddingNumbers:
    def __init__(self, x):
        self.x = x

    def __add__(self, other, some):
    # def __mul__(self, some):
        if isinstance(some.x, str):
            y = int(some.x)
            return self.x * y * some.x

#
x = AddingNumbers(5)
y = AddingNumbers("10")
print(x * y)

# a = 20
# b = 6
# print(b * a)
# print(b.__mul__(a))

class Fun:
    def __init__(self, x):
        self.x = x

obj = Fun(5)
print(obj.x)