"""
Author : GOVIND
Date   : 22-07-2024
"""


class A:
    def method(self):
        return "Method from class A"


class B(A):
    # def method(self):
    #     return "Method from class B"
    pass


class C(A):
    # def method(self):
    #     return "Method from class C"
    pass


class D(B, C):
    # def method(self):
    #     return "Method from class D"
    pass


d = D()

print(d.method())

print(D.mro())

"""
In the Method Resolution Order (MRO) of a class hierarchy, 
object is typically the last class listed. 
It serves as the ultimate fallback for method and attribute resolution. 
If Python cannot find a method or attribute in any of the explicitly 
listed classes in the MRO, it will ultimately check object.

So, when you see <class 'object'> in a Method Resolution Order like 
[D, B, C, A, object], it indicates that object is the ultimate base class 
in the hierarchy.
"""
