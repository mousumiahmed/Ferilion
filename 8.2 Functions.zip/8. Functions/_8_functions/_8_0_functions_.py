"""
Author : GOVIND 
Date   : 08-07-2024
"""
"""
functions:
----------
procedural - input()
functional - 
oop

def keyword - function name(identifiers) - (parameters(optional)):
    block of code
    
another line


f(x) = 2x + 3

def f(x):
    res = 2*x + 3
    print(res)

functions - outside the class
methods   - inside the class - object is involved - .

params : while defining the function we will pass the variables 
args   : while calling the function we are passing the values

print  : 
return : 

default args    : creating the function
params without default followed by default args

positional args : calling the function params order is preserved
keyword args   : calling the function using param names provide the values -> param_name = value

positional args followed by keyword args

*args
**kwargs

"""

# n1 = int(input("enter num1"))
# n2 = int(input("enter num2"))
# res = n1 + n2
# print(res)

# def add_two_int(n1, n2):
#     ls = [1, 2, 3]
#     res = n1 + n2
#     # return res
#     # print(res)
#     # print(n1)
#     # print(n2)
#     return(res)
# return(n1)
# return(n2)

# print(id(add_two_int))
# add_two_int(10, 2)
# x = add_two_int(10, 2)
# print(x)

# def another_func():
#     x = add_two_int(10, 20)
#     print(f"x value is {x}")
#
# another_func()

# def func1():
#     print("entering func1")
#     func2()
#     print("exiting from func1")
#
# def func2():
#     print("entering func2")
#     func3()
#     print("exiting from func2")
#
# def func3():
#     print("entering func3")
#     print("exiting from func3")
#
# func1()

# def add_two_int(n1, n2=9):
#     res = n1 + n2
#     return res, n1, n2
#
# x,y,z= add_two_int(5, 20)
# print(x)
# print(y)
# print(z)

# p, q, r = 2, 5, 7
# print(p)
# print(q)
# print(r)

# for _ in range(5):
#     print("hi")

# def emp_data(name, age=35 ):
#     res = f"my name is {name} and age is {age}"
#     return res
#
# x= emp_data("Rajesh", age=50, )
# print(x)
# print(y)
# print(z)

# def func(*args, n2=99):
#     sum = 0
#     for each in args:
#         sum += each
#     return sum, args, n2
#
# print(func(5, 7, 8, 5))

# def functwo(n2, **kwargs):
#     # return kwargs, type(kwargs)
#     return kwargs, n2
#
#
# y = functwo(1000, name="Ramesh", age=25, )
# print(y)

# def func2(n1=5, n2=10):
#     return n1+n2
# print(func2())
# (2, (2,))

# def func(*args):
#     sum = 0
#     # ls = []
#     for each in args:
#         if isinstance(each, (int, float)):
#             sum += each
#
#     return(sum)
#
#
# print(func(5, 7.5, 8, 5, "python"))

"""
function methods
print return
params args default args positional keyword *args **kwargs

def functioname(params(optional)):
    block of code

while defining the functions - p, *args, default args, **kwargs
while calling the functions  - p, *args, default or **kwargs


nested function
recursive 
decorator

LEGB

lambda
typing - module

"""
# LEGB

# # from math import pi
# # pi = "global space"
# def outer():
#     # pi = "enclosed space"
#     def inner():
#         # pi = "local space"
#         print(pi)
#     return inner()
#
# outer()

# nested

# def outer(x):
#     def inner(y):
#         res = x + y
#         return res
#     return inner

# calling_outer_func = outer(5)
# print(calling_outer_func)
# calling_iiner_func = calling_outer_func(6)
# print(calling_iiner_func)

# def func(x):
#     return x
# y = func(5)
# def outermost():
#     def outer():
#         def inner():
#             def innermost():
#                 return "inner"
#             return innermost
#         return inner
#     return outer
#
# y = outermost()


# # nested function

# def another_func():
#     print("another_func")
#     def outermost_func():
#         print("outermost_func")
#         def outer_function():
#             print("outer_function")
#             def inner_function():
#                 return "inner_function"
#             return inner_function
#         return outer_function
#     return outermost_func
#
# res = another_func()

# recursive -

# def factorial(n):
#     if n == 0 or n==1:
#         return 1
#     else:
#         return n * factorial(n-1)
#
# res = factorial(4)
# print(res)
#
# """
# factorial(4) -> return 4 * factorial(3)
# factorial(3) -> return 3 * factorial(2)
# factorial(2) -> return 2 * factorial(1)
# factorial(1) -> 1
#
# factorial(2) -> return 2 * 1 = 2
# factorial(3) -> return 3 * factorial(2) = 3 * 2 = 6
# factorial(4) -> return 4 * factorial(3) = 4 * 6 = 24

# """


# ls = [1, 2, [5, 9], [8, 5, [22, "a", ["new", 100]]]]
# new_ls = []
# for each in ls:
#     if isinstance(each, list):
#         new_ls.extend(each)
#     else:
#         new_ls.append(each)
#
# print(new_ls)
#

"""
decorator - without changing the source code adding features to that code
"""


# def decorator(func):
#     def wrapper():
#
#         print("before calling the func")
#         data()
#         print("after calling the function")
#
#     return wrapper
#
# @decorator
# def data():
#     print("i am from data function")
#
#
# data()
# """
# before calling the func
# i am from data function
# after calling the function
#
#
# logging - data validation -
# """

"""
lambda - keyword -> one time usage function without using def key

lambda arguments: expression

lambda     : keyword
arguments  : any number of arguments
expression : only one 

map filter reduce

map    -> map a lambda fuc with iterables
filter -> filter a iterable using lambda func
reduce -> functools - x, y
"""

# add = lambda x, y : x+y
# print(add(5, 6))

# ls = [11, 22, 33, 44, 55, 66, 77, 88, 99]
# print(dir(list))
# map_obj = str(map(lambda x: x**2, ls))
# print(map_obj)
# print(next(map_obj))
# print(next(map_obj))
# print(next(map_obj))

# filter_obj = list(filter(lambda x: x%2==0, ls))
# print(filter_obj)

# from functools import reduce
#
# red = reduce(lambda x, y: x+y, ls)
# print(red)


