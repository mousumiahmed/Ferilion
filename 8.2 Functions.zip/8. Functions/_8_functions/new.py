"""
Author : GOVIND 
Date   : 09-07-2024
"""

# def emp_data(name: str, age: int) -> str:
#     return [age]
#
# print(emp_data(25, "100"))

def emp_data(name: str, age:int) -> str:
    """
    :param name: str type should contain max 25 chars
    :param age: int between 0 - 80
    :return: str with param name and param age
    """
