"""
Author : GOVIND
Date   : 02-08-2024
"""


class TimesFive:
    def __init__(self, func):
        self.func = func

    def __call__(self, *args, **kwargs):
        result = self.func(*args, **kwargs)
        # c = 0
        # for each in args:
        #     c+=each
        # return c
        # return result * 5
        return "Hello"
@TimesFive
def multiply(a, b):
    return a * b


print(multiply(2, 3))
#
"""
__call__ method:

This method defines how the class instance behaves when called.
In Python, anything implementing this method can be used like a function.
Here, when we call the decorated function, it will first call this __call__ method.

"""


def my_class_decorator(cls):
    class NewClass(cls):
        def new_method(self):
            return "This is a new method added by the decorator"
    return NewClass

@my_class_decorator
class MyClass:
    def existing_method(self):
        return "This is an existing method."

obj = MyClass()
print(obj.existing_method())
print(obj.new_method())
