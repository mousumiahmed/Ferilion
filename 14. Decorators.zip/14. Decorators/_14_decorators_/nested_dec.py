"""
Author : GOVIND
Date   : 02-08-2024
"""
import time


def timing_decorator(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        res = func(*args, **kwargs)
        end_time = time.time()
        execution_time = end_time - start_time
        print(f"Function '{func.__name__}' executed in: {execution_time} seconds")
        return res

    return wrapper


def logging_decorator(message):
    def wrapper(func):
        def inner(*args, **kwargs):
            print(f"--- Before calling {func.__name__}: {message}")
            ress = func(*args, **kwargs)
            print(f"--- After calling {func.__name__}: {message}")
            return ress

        return inner

    return wrapper


@logging_decorator("This is a timing log")  # Outer decorator (logging)
@timing_decorator  # Inner decorator (timing)
def my_function(a, b):
    time.sleep(1)
    return a + b


result = my_function(5, 3)
print(f"output of original function: {result}")
"""
Explanation:
------------
The innermost wrapper function (from logging_decorator) is executed first.
It prints the "Before" message.
Then, it calls the next layer of decoration (which is the wrapper from timing_decorator).
The timing_decorator's wrapper records the start time.
It calls the actual my_function with the arguments.
my_function sleeps for 1 second and returns the sum (5 + 3).
The timing_decorator's wrapper records the end time, calculates the execution time, 
and prints it.
Finally, the outermost wrapper (logging_decorator's wrapper) prints the 
"After" message and returns the result (8).
"""