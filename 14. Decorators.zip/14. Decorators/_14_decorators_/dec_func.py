"""
Author : GOVIND
Date   : 02-08-2024
"""
def another_func(num):
    def print_args_kwargs(func):
        def wrapper(*args, **kwargs):
            # action part
            print(f"num is {num}")
            print("Arguments:", args)
            print("Keyword Arguments:", kwargs)
            return func(*args, **kwargs)

        return wrapper
    return print_args_kwargs


@another_func(num=8)
def example_function(a, b, c=1, d=2):
    print("Inside example_function")
#
#
example_function(1, 2, c=3, d=4)

""" ******************************************************  """


#
# def sample_decorator(func):
#     def wrapper(*args, **kwargs):
#         before_message = "Before calling the function"
#         result = func(*args, **kwargs)
#         after_message = "After calling the function"
#         return before_message, result, after_message
#
#     return wrapper
#
#
# @sample_decorator
# def my_function(x, y):
#     return x + y
#
#
# result = my_function(3, 5)
# print(result)


#
# def first(func):
#     def wrapper(*args, **kwargs):
#         # print("i am calling first decorator")
#         func(*args, **kwargs)
#         print(args)
#         print(kwargs)
#     return wrapper
#
# @outer
# def fun(x, y, z):
#     print("hi")
# fun(10, 20, z="python")
#
# @outer
# def some():
#     print("hello")
#

# nested function
# outer function which takes function as a parameter
# call this function(which we are passing as a param) in the wrapper function
# return wrapper function
