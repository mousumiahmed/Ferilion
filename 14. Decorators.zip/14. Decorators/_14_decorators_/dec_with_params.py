"""
Author : GOVIND
Date   : 02-08-2024
"""


def repeat(num_times):
    def decorator_repeat(func):
        def wrapper(*args, **kwargs):
            # print(num_times)
            for _ in range(num_times):
                result = func(*args, **kwargs)
            return result

        return wrapper

    return decorator_repeat


@repeat(num_times=3)
def greet(name):
    print(f"Hello, {name}")


greet("Rajesh")

""" ******************************************************  """
#
#
# def log_with_level(level):
#     def decorator_log(func):
#         def wrapper(*args, **kwargs):
#             print(f"[{level}] Calling function '{func.__name__}'")
#             result = func(*args, **kwargs)
#             print(f"[{level}] Function '{func.__name__}' execution completed")
#             return result
#
#         return wrapper
#
#     return decorator_log
#
#
# @log_with_level(level="INFO")
# def add(x, y):
#     return x + y
#
#
# @log_with_level(level="DEBUG")
# def subtract(x, y):
#     return x - y
#
#
# print(add(3, 5))
# print(subtract(10, 7))
