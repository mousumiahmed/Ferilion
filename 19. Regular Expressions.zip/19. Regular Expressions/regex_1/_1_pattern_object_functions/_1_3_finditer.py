"""
finditer() - Find all substrings where the RE matches, and returns them as an iterator.
"""

import re


pattern = re.compile(r'\d+')

iterator = pattern.finditer('12 drummers drumming, 11 ... 10 ...')

print(f'iterator : {iterator}')
print(pattern.findall('12 drummers drumming, 11 ... 10 ...'))
for each in iterator:
    # print(each)
    # print(each.span())
    print(each.group())


