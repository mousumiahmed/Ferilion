""" """
"""
pattern.match()
---------------

- Returns  : A match object if the pattern matches at the beginning 
             of the string. If there's no match, it returns `None`.
- Use Case : If you want to check if the pattern matches at 
             the beginning of the string.
"""
# import re
#
# pattern = re.compile(r'\d+')  # Match one or more digits
# m = pattern.match('123 numbers')
# # print(pattern)
# if m:
#     print('Match found:', m.group())
# else:
#     print('No match')

"""
pattern.search()
----------------
- Returns  : A match object if the pattern is found anywhere in 
             the string. If there's no match, it returns `None`.
- Use Case : If you want to find the first occurrence of the pattern 
             in the string.
"""
# import re
#
# pattern = re.compile(r'\d+')  # Match one or more digits
# m = pattern.search('A string containing 123 numbers')
# if m:
#     print('Pattern found:', m.group())  # Output: Pattern found: 123
# else:
#     print('Pattern not found')
#

"""
pattern.findall()
-----------------

- Returns  : A list of all non-overlapping matches of the pattern in 
             the string.
- Use Case : If you want to find all occurrences of the pattern in 
             the string and retrieve them as strings.
"""
# import re
#
# pattern = re.compile(r'\d+')  # Match one or more digits
# matches = pattern.findall('A string containing 123 numbers and 456 more numbers')
# print(matches)

"""
pattern.finditer()
------------------

- Returns  : An iterator yielding match objects for each 
             non-overlapping match of the pattern in the string.
- Use Case : If you want to find all occurrences of the pattern 
             in the string and retrieve detailed information 
             about each match.

"""
import re

pattern = re.compile(r'\d+')  # Match one or more digits
matches = pattern.finditer('A string containing 123 numbers and 456 more numbers')
# print(matches)
for match in matches:
    print(match.group(), match.span())
#
