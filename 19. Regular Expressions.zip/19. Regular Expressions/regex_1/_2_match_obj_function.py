""" """
"""
group()

- Functionality : Returns the substring of the input string 
                  that was matched by the regular expression.
"""
# import re
#
# pattern = re.compile(r'\d+')
# m = pattern.search('A string containing 123 numbers')
# if m:
#     print('Match found:', m.group())

""" 
start()
-------

- Functionality : Returns the start index of the matched substring 
                  within the input string.
"""
#
# import re
#
# pattern = re.compile(r'\d+')
# m = pattern.search('A string containing 123 numbers')
# if m:
#     print('Match starts at index:', m.start())

"""
end()
-----

- Functionality : Returns the end index (exclusive) of the matched 
                  substring within the input string.
"""

import re

pattern = re.compile(r'\d+')
m = pattern.search('A string containing 123 numbers')
if m:
    print('Match ends at index (exclusive):', m.end())

"""
span()
------

- Functionality : Returns a tuple containing the start and end 
                  indices (exclusive) of the matched substring 
                  within the input string.
"""


import re

pattern = re.compile(r'\d+')
m = pattern.search('A string containing 123 numbers')
if m:
    print('Match span (start, end):', m.span())  # Output: Match span (start, end): (19, 22)
