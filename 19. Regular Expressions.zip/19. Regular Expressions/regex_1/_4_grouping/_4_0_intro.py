"""
Groups are marked by the '(', ')' metacharacters.
have much the same meaning as they do in mathematical expressions;
they group together the expressions contained inside them,
and you can repeat the contents of a group with a quantifier, such as *, +, ?, or {m,n}

"""
