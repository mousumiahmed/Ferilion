""" """
""" 
split()
--------
- Functionality: Splits the input string into a list of substrings 
                 using the matched pattern as a delimiter.
"""


import re

pattern = re.compile(r'\d+')
s = 'A string containing 123 numbers'
result = pattern.split(s)
print(result)


""" 
sub()

- Functionality: Replaces occurrences of the matched pattern in the 
                 input string with a specified replacement string.
"""

import re

pattern = re.compile(r'\d+')
s = 'A string containing 123 numbers'
result = pattern.sub('CHANGED', s)
print(result)


"""
subn()
------

- Functionality: Similar to sub(), but also returns the number of 
                  substitutions made.
"""


import re

pattern = re.compile(r'\d+')
s = 'A string containing 123 numbers'
result, count = pattern.subn('CHANGED', s)
print(result)
print(count)
