"""
Author : GOVIND 
Date   : 18-07-2024
"""

# class NewClass:
#     class_var = "class var"
#     _prot_class_var = "_prot_class_var"
#     __private_class_var = "__private_class_var"
#
#     def __init__(self, param1, param2):
#         self.param1 = param1
#         self.param2 = param2
#         self._prot_instance_var = "_prot_instance_var"
#         self.__private_instance_var = "__private_instance_var"
#
#     def instance_meth(self):
#         return f"I am from instance_meth"
#
#     def another_inst(self):
#         return (f"{self.param1}, {self.param2}, {self._prot_instance_var}, {self.__private_instance_var}"
#                 f"{self.instance_meth()}, {NewClass.__private_class_var}, {NewClass._prot_class_var}, {NewClass.class_var}")
#
#     @staticmethod
#     def utility():
#         return "i am from static method"
#
#     @classmethod
#     def class_method(cls):
#         return f"{cls.class_var}, {cls._prot_class_var}, {cls.__private_class_var}"
#
#     @property
#     def fun(self):
#         return "I am from property decorator"
#
#
# obj = NewClass("valueone", "valuetwo")
#
# # print(obj.class_var, obj._prot_class_var)
# # print(obj.param1, obj._prot_instance_var)
# # print(obj.instance_meth())
# # print(obj.another_inst())
# # print(obj.class_method())
# # print(obj.utility())
#
# print(obj.fun)

# class Person:
#     def __init__(self, name, age):
#         self.name = name
#         self._age = None
#         self.age = age
#
#     @property
#     def age(self):
#         return self._age
#
#     @age.setter
#     def age(self, value):
#         if not isinstance(value, int) or value < 0:
#             raise ValueError("age must be a positive int")
#         # self._age = value
#         setattr(self, '_age', value)
# # try:
# #     obj = Person("Ramesh", "lksnd")
# #     print(obj)
# # except ValueError as e:
# #     print(e)
#
# obj = Person("ramesh", 25)
# print(obj.age)
#
# setattr(obj, 'age', "two")
# print(obj.age)

"""
inheritance:
------------
single inheritance
multiple inheritance
multilevel inheritance
hierarchical inheritance
hybrid inheritance

"""

# single inheritance
# class A:
#     def method_A(self):
#         return "i am from class A"
#
#
# class B(A):
#     def method_B(self):
#         return "i am from class B"
#
# obj = B()
# print(obj.method_A(), obj.method_B())

'multiple inheritance'

#
# class A:
#     def method_A(self):
#         return "i am from class A"
#
#
# class B:
#     def method_B(self):
#         return "i am from class B"
#
#
# class C(A, B):
#     def method_C(self):
#         return f"i am from class C {self.method_B(), self.method_A()}"
#
#
#
# obj = C()
# print(obj.method_A(), obj.method_B(), obj.method_C())

'multilevel inheritance'

# class A:
#     def method_A(self):
#         return "i am from class A"
#
#
# class B(A):
#     def method_B(self):
#         return f"i am from class B {self.method_A()}"
#
#
# class C(B):
#     def method_C(self):
#         return f"i am from class C {self.method_B(), self.method_A()}"
#
#
#
# obj = C()
# print(obj.method_A(), obj.method_B(), obj.method_C())


'hierarchical inheritance'
# class A:
#     def method_A(self):
#         return "i am from class A"
#
#
# class B(A):
#     def method_B(self):
#         return f"i am from class B {self.method_A()}"
#
#
# class C(A):
#     def method_C(self):
#         return f"i am from class C { self.method_A()}"
#
#
#
# obj = C()
# print(obj.method_A(), obj.method_C())
# obj_b = B()
# print(obj_b.method_A(), obj_b.method_B())

'hybrid inheritance'


# class A:
#     def method_A(self):
#         return "i am from class A"
#
#
# class B(A):
#     def method_B(self):
#         return f"i am from class B "
#
#
# class C(A):
#     def method_C(self):
#         return f"i am from class C"
#
#
# class D(B, C):
#     def method_D(self):
#         return f"i am from class D"

# obj = D()
# print(obj.method_A(), obj.method_B(), obj.method_C(), obj.method_D())

# class E(B, A):
#     def method_E(self):
#         return f"i am from class E {self.method_B()}, {self.method_A()}"
#
# obj = E()
# print(obj.method_A(), obj.method_B(), obj.method_E())
#
"""
# class A:
#     # def meth(self):
#     #     return "i am from class A"
#     pass
#
# class B(A):
#     # def meth(self):
#     #     return f"i am from class B "
#     pass
#
# class C(A):
#     # def meth(self):
#     #     return f"i am from class C"
#     pass
#
# class D(B, C):
#     # def meth(self):
#     #     return f"i am from class D"
#     pass
#
# # obj = D()
# # print(obj.meth())
#
# """
# class D -> class B -> class C -> class A
#
# mro -
#
# [<class '__main__.D'>, <class '__main__.B'>, <class '__main__.C'>, <class '__main__.A'>, <class 'object'>]
# [<class '__main__.D'>, <class '__main__.B'>, <class '__main__.C'>, <class '__main__.A'>, <class 'object'>]
#
#
# """
# print(C.mro())

#
# class A:
#     def method_A(self):
#         return "i am from class A"
#
#
# class B(A):
#     def method_B(self):
#         return f"i am from class B "
#
#
# class C(B):
#     def method_C(self):
#         return f"i am from class C"
#
#
# class D(B, C):
#     def method_D(self):
#         return f"i am from class D"
# obj = D()
# print(obj)

""
#
# class A:
#     def method_A(self):
#         return "i am from class A"
#
#
# class B(A):
#     def method_B(self):
#         return f"i am from class B "
#
#
# class C(B):
#     def method_C(self):
#         return f"i am from class C"
#
#
# class D(C, A):
#     def method_D(self):
#         return f"i am from class D"
# #
# class E(B, A):
#     def method_E(self):
#         return f"i am from class E "

# obj = E()
# print(E.mro())


class A:
    # def __init__(self, name):
    #     self.name = name

    def meth(self):
        return "{self.name}"

class B(A):
    # def __init__(self, age):
    #     self.age = age
    def another(self):
        x = self.meth()
        return x
obj = B()
print(obj.another())