"""
Author : GOVIND
Date   : 14-08-2024
"""
import urllib.parse
# url = "https://reqres.in/api/users?page=2"
url = "https://flask-sqlalchemy.palletsprojects.com/en/3.1.x/quickstart/#create-the-tables"
# url = "https://www.example.com/path/to/page;param=value?query=query_example#fragmentAnchor"
# Get res with parts of url
res = urllib.parse.urlparse(url)

# Display contents
print(res)
print("Scheme : ", res.scheme)
print("Netloc : ", res.netloc)
print("Params : ", res.params)
print("Port   : ", res.port)
print("Query   : ", res.query)
print("URL    : ", res.geturl())
print("Path,suffix url   : ", res.path)
