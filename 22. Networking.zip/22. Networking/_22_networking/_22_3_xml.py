"""
Author : GOVIND
Date   : 14-08-2024
"""
# pip install xmltodict
# pip install dicttoxml
import xmltodict

# XML data
xml_data = """
<new>    
    <book>
        <title>Python Programming</title>
        <author>John Doe</author>
        <year>2022</year>
    </book> 
</new>  
"""

# Parse XML into Python dictionary
parsed_dict = xmltodict.parse(xml_data)

# Print parsed dictionary
print("Parsed Dictionary:")
print(parsed_dict)

"""*************************************************"""

import dicttoxml

# Python dictionary
book_dict = {
    "book": {
        "title": "Python Programming",
        "author": "John Doe",
        "year": "2022"
    }
}

# # Convert dictionary to XML
xml_data = dicttoxml.dicttoxml(book_dict)

# Print XML data
print("XML Data:")
print(xml_data.decode())
