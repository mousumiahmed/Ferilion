"""
Author : GOVIND
Date   : 14-08-2024
"""
# https://reqres.in/
# pip install requests
"""
C R U D
GET  - R
POST - CREATE
PUT   - 
PATCH - 
DELETE - DELETE
"""
import json
import requests
#
base_url = 'https://reqres.in/api'
#
#
# GET request to list users
def get_users():
    response = requests.get(f'{base_url}/users')
    #
    # print("response.json() = ", response.json(), '\n')
    # print("response.json() = ", type(response.json()), '\n')
    # print("response.status_code = ", response.status_code, '\n')
    # print("response.headers = ", response.headers, '\n')
    # print("response.request = ", response.request, '\n')
    # print("response.text = ", type(response.text), '\n')
    # print("response.text = ", response.text, '\n')
    # print("response.content = ", response.content, '\n')
    # print("response.raw = ", response.raw, '\n')
    # print("response.url = ", response.url)
    print("response.text = ", response.text, '\n', type(response.text))
    x = json.loads(response.text)
    print(x, type(x))


# get_users()
# POST request to create a new user
def create_user(name, job):
    payload = {
        'name': name,
        'job': job
    }
    response = requests.post(f'{base_url}/users', json=payload)
    data = response.json()
    print(data)
    print(type(data))
    print(response.status_code)

    # print(f"ID: {data['id']}, Name: {data['name']}, Job: {data['job']}, Created At: {data['createdAt']}")


create_user('Ramesh', 'Python Developer')

# GET request to retrieve a specific user
def get_user(user_id):
    response = requests.get(f'{base_url}/users/{user_id}')
    data = response.json()
    print(data)
    # print(type(data))

    # print(f"ID: {data['data']['id']}, Name: {data['data']['first_name']} {data['data']['last_name']}, Email: {data['data']['email']}")

# get_user(23)


def update_user(user_id, name, job):
    payload = {
        'name': name,
        'job': job
    }
    response = requests.put(f'{base_url}/users/{user_id}', json=payload)
    data = response.json()
    print(data)
    print(type(data))

    print(f"Updated At: {data['updatedAt']}, Name: {data['name']}, Job: {data['job']}")
# update_user(2, "Ramesh", "Product Manager")


def delete_user(user_id):
    response = requests.delete(f'{base_url}/users/{user_id}')
    print(f"Status Code: {response.status_code}")
    if response.status_code == 204:
        print("User deleted successfully.")
    else:
        print("Failed to delete user.")
# delete_user(2)


