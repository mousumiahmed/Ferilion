"""
Author : GOVIND
Date   : 14-08-2024
"""
"""
json.loads(): This function is used to parse JSON strings (text) and convert them into 
              Python objects (dictionaries, lists, strings, numbers, booleans, and None).
json.dumps(): This function is used to serialize Python objects 
              (dictionaries, lists, strings, numbers, booleans, and None) into JSON strings.
"""

import json
#
# # JSON string
# json_str = '{"name": "John", "age": 30, "city": "New York"}'
# json_str = '{1, 2, 3}'
# json_str = '100.5'
# json_str = 'true'
# json_str = 'null'

#
#
# # Parse JSON string into Python dictionary
# # Deserialize the object
#
# data = json.loads(json_str)
# print("Parsed JSON data   : ", data)
# print("type of json.loads : ", type(data))
#
# # Serialize Python dictionary into JSON string
# # Serialize the object (JSON format)
data = {"name": "John", "age": 30, "city": "New York"}
data = [1,2,3]
data = (1, 2, 3)
data = 100
data = 3.5
data = False
data = None
# json_data = json.dumps(data)
# # for each in json_data:
# #     print(each)
# print("Serialized JSON data :", json_data)
# print("type of json.dumps   : ", type(json_data))
# print(str(data))
#


"""
Pickling   : Pickling is the process of serializing Python objects into a byte stream. 
Unpickling : Unpickling is the process of deserializing the byte stream back 
             into Python objects.


"""
# import pickle
# #
# # # Python object
# # data = {"name": "John", "age": 30, "city": "New York"}
# # data = ["a", "b", 100]
# data = "python"
# #
# # # Pickle the object
# pickled_data = pickle.dumps(data)
# print("Pickled data:", pickled_data)
# print("Pickled data:", type(pickled_data))
#
# # Unpickle the object
# unpickled_data = pickle.loads(pickled_data)
# print(unpickled_data)
# print("Unpickled data:", type(unpickled_data))
