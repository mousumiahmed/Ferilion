"""
Author : GOVIND
Date   : 13-08-2024
"""
"""

https://flask-sqlalchemy.palletsprojects.com/en/3.1.x/

https://www.amazon.in/s?k=iphone&crid=29Z70XGA1NOYF&sprefix=%2Caps%2C281&ref=nb_sb_ss_recent_1_0_recent

C - POST
R - GET
U - PUT, PATCH
D - DELETE

API - application programming interface

https://employee.com/

/create_employe
/update_employee
/get_employee_data
/delete_employee_data


phonepe - HDFC bank - /fetch_balance - {"balance": 1000}
phonepe - SBI       - /get_bance - {"balance": 1000}
phonepe - Indian    - /balance - {"balance": 1000}

HTTP METHODS -
STATUS CODES - 

1XX - informational
2XX - 200, 201, 204 
3XX - redirection 
4XX - client errors
5XX - server errors


https://reqres.in/api/users - GET
https://reqres.in/api/users - POST
"""

