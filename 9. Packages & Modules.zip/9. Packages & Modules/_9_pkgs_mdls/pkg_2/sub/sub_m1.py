"""
Author : GOVIND 
Date   : 15-07-2024
"""
from pkg_2 import *

# from ..pk_m2 import pk_m2_var
from pkg_2.pk_m2 import pk_m2_var
# from .
print(pk_m2_var)
x = 10


def func():
    pass


def func2():
    pass
