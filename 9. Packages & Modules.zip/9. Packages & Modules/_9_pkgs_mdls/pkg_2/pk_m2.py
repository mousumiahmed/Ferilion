"""
Author : GOVIND 
Date   : 15-07-2024
"""
# from pkg1.pk_m1 import *


pk_m2_var = "from pk_m2"

from pkg_2 import k2

print(k2)


def pk_m2_func():
    return "from pk_m2 func"

# print(pk_m1_var)
# print(pk_m1_func())