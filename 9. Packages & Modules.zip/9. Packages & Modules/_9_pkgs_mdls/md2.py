"""
Author : GOVIND 
Date   : 15-07-2024
"""
# import md1

from md1 import sample, sample_func
# print(sample)
m2_var = "from m2"

def m2_func():
    return "from m2 func"

# print("hi from m2")
res = m2_func()
# print(f"calling {res}")
sample_func()
# calling from md1