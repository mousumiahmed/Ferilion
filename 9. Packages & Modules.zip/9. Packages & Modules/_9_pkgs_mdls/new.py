"""
Author : GOVIND 
Date   : 15-07-2024
"""
"""
module -> .py file -> constants, comments, # """ """, functions, class, variables 

directory/folder -> collection of modules - subdirectiorie - modules - packages

package -> collection of modules - directiorie - packages - __init__.py

library -> standard , userdefined , thirdparty

conda - xx
pip  ->

md1 - md2
md1 - pkg1
md1 - d1

pkg1 - pkg2
pk1- md1
pk1 - d1

d1 - d2
d1 - md1
d1 - pk1


"""


