"""
Author : GOVIND 
Date   : 15-07-2024
"""
print("I am from pkg 1")

var = "var"