"""
Author : GOVIND 
Date   : 15-07-2024
"""
pk_m1_var = "from pk_m1_var"


def pk_m1_func():
    var
    return "from pk_m1 func"
