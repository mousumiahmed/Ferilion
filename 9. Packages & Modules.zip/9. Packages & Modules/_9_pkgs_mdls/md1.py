"""
Author : GOVIND 
Date   : 15-07-2024
"""
# from md2 import m2_var, m2_func
# from md2 import *

# from pkg_2 import pk_m2
# import md2
m1_var = "from m1"


def m1_func():
    return "from m1 func"


# print(pk_m2.pk_m2_func())

# print(md2.m2_var)
# print(md2.m2_func())
# sample = "hi"

# if __name__ == '__main__':
#     # sample = "hi"
#     pass

# def sample_func():
#     if __name__ == '__main__':
#         print(f"calling from {__name__}")
#     else:
#         print(f"calling from {__name__} ")

# sample_func()
# calling from __main__
