"""
Author : GOVIND 
Date   : 29-06-2024
"""
"""
req:
----
state - input output - dt/ds

dt/ds
int, float, complex, bool, string, list[], tuple(), set{} , dictionary{key:value}

req: add two positive integers and provide the result

input state  : two int - 2, 3
behavior     : B.L - CRUD - DM, LOOPS, OPERATORS (res = n1 + n2 -> print(res))
output state : int     - 5

CREATE
RETRIEVE
UPDATE
DELETE
"""

"""
operators:
----------
Arithmetic
Comparison
Logical
Membership
Assignment
Identity
Bitwise

"""
"""
Arithmetic
----------
+ - * ** / // %

"""
# n1 = "100"
# n2 = False
# res = n1 ** n2
# print(res)

"""
comparison
-----------
== > < != >= <=

"""
# ls1 = [1,2, False]
# ls2 = [1,2]
#
# print(ls1 > ls2)
# print(10 > 5)
"""
logical operators - DM
and or not
p   q    p and q   p or q   not p
------   -------   ------   ------
T   T       T         T       F
T   F       F         T       F
F   T       F         T       T
F   F       F         F       T
"""
# print(True and False)
# print(True or False)
# print(not True)
# print(10 and 5)
# print(5 and 10)
# print("a" and "A")
# print(10 and "a")
# print("a" and 10)
# print(1 and 0)
# print(0 and 1)
# print(0 and 100)
# print(100 and [100])

# print(10 or 5)
# print(5 or 10)
# print("a" or "A")
# print(10 or "a")
# print("a" or 10)
# print(1 or 0)
# print(0 or 1)
# print(0 or 100)
# print(100 or 0)
# print(not 100)

"""
membership operator: LOOPS
--------------------
in
collection of data - string, list, tuple, set, dictionary, range
"""
# ls = ["python", 22, 55]
# ls = "python"
# ls = {"name":"Rajesh", "age":30, "salary": 1000}
# ls = 100
# print(1 in ls)

"""
assignment - shortform
-----------------------
+= , -=, *=, **= /=, //=, %=

"""
# n = 10
# # n = n + 5
# n /= 5
# print(n)

"""
identity operators:
--------------------
is

"""
# n1 = (1,)
# n2 = ()
# print(id(n1))
# print(id(n2))
# print(n1 is n2)

# x = 2
# print(bin(x))
# # 0b 0001
# # print(5 | 3)
