"""
Author : GOVIND
Date   : 29-06-2024
"""

"""
Bitwise AND ( & )
-------------- 
p = 5   binary: 0101
q = 3   binary: 0011
p & q           0001

                
Bitwise OR ( | )
-------------------
p = 5   binary: 0101
q = 3   binary: 0011
p | q           0111


Bitwise XOR ( ^ )
--------------------
p = 5   binary: 0101
q = 3   binary: 0011
p ^ q           0110

Bitwise NOT ( ~ )
--------------------
num = 10 => 1010 (Binary)
~num = ~1010 = -(1010+1) = -(1011) = -11 (Decimal)


# Bitwise left shift(the binary number is appended with 0s at the end)
x = 10 => 1010 (Binary)
x<<2 = 1010 << 2
     = 101000 = [(2**0) * 0]+ [(2**1) * 0] + [(2**2) * 0] + [(2**3) * 1] + [(2**4) * 0] + [(2**5) * 1]
     = 40

# Bitwise right shift(in binary number the right side bits are removed)
x = 10 => 1010 (Binary)
x >> 2 = 1010 >> 2
       = 0010 = [(2**0) * 0]+ [(2**1) * 1] + [(2**2) * 0] + [(2**3) * 0]
       = 2

"""
