"""
Author : GOVIND 
Date   : 27-06-2024
"""
"""
python:
-------
simple english + basic maths

High level        - __pycache__ .pyc .py
interpreted       - executes the code line by line
dynamically typed - no declaration

oop

clear syntax - indentations :
readability
portability - 
open source -
extensive standard libraries - 200+
extensive third party libraries - 

web applications
flipkart - web applications
Notepad  - standalone applications

AI ML 

procedural      - input()
functional      - def 
object oriented - class
"""
# import datetime
# import math
# import json
# import re
# import time
# name = "Harish"
# print(name, type(name))
# age = 30
# print(age, type(age))
# salary = 1000.5
# print(salary, type(salary))
#
# # def funcone():
# #     print("before sleeping")
# #     time.sleep(1)
# #     print("done sleeping")
# # t1 = time.time()
# # funcone()
# # funcone()
# # t2 = time.time()
# # print(t2-t1)
#

name = "rajesh" # static
print(name)
name_2 = input("enter a name: ") # dynamic
print(name_2)
# print, input, type
