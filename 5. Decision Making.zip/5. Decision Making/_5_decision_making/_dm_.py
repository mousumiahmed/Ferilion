"""
Author : GOVIND 
Date   : 01-07-2024
"""
"""
req:
----
state - dt/ds - input output
behavior - B.L - CRUD - DM LOOPS OPERATORS

mutable   : list, set, dictionary
immutable : int, float, complex, bool, string, tuple

iterables     : string, list, set, tuple, dictionary, range
sequence type : string, list, tuple

Decision Making:
----------------
if condition1 :
    execute this block of code if condition1 is True
elif condition2:
    execute this block of code if condition1 is False and condition2 is True
elif condition3:
    execute this block of code if condition1 is False and condition2 is False and condition3 is True    
else:
    if all the above conditions are false then execute this block of code
    
    

# logical operators - and, or, not

if condition1 and condition2:
    execute this block of code - both condition1 True and condition2 should be True
    
if day == "weekend" and money > 500:
    print("i will go to movie")
    

if condition1 or condition2:
    execute this block of code - either condition1 is True or condition2 is True

if day == "weekend" or money > 500:
    print("i will go to movie")
    
if not condition1:
        execute this block of code - condition1 is None or no data is present
        
# no data present
# s = ""
# s = 0
# s = []
# s = ()
# s = {}
# s = set()
# s = False
# s = None

# data is present

# s = range(5)
# s = True
# s = -2
# s = 3+4j
# s = 2
# s = 3.5

if not s:
    print("no data present")
else:
    print("data is present")

if day != "weekend" :
    print("i will go to movie")
    

"""
# money = int(input("enter money : "))
# day_type = input("enter day type weekend/weekday")
# int(), float()
# new_mon = float(money)
# print(new_mon)
# print(type(new_mon))
# print(5 * money)
# req 5000 - go to trip > 1000 > shopping > 500 go to movie
#
# if money > 500 and money < 1000:
# if 500 < money < 1000:
#
#     print("i will go to movie")
#     # print("i will go to restaurant")
#
# if money > 1000:
#     print("i will go to shopping")
# else:
#     print("i will study")
'******************************************************************************'

# money = int(input("enter money : "))
# day_type = input("enter day type weekend/weekday")

# and, or, not
#  T            or       F
# if money > 1000 or day_type == "weekend":
#     print("go to shopping")

# not
# print(5 and None)
# s = ""
# if not s:
#     print("no data is present")
# ls = None
# incomming_data = eval(input("enter a dict: "))
# # incomming_data = input("enter a dict: ")
#
# ls = incomming_data
# print(ls, type(ls))
# print(list(ls))
# if ls:
#     print(ls["name"])
'******************************************************************************'

# marks = int(input("input of enter marks b/w 0 and 100: "))
#
# # if marks >= 75 and marks <= 100:
# #     print("first class")
# # elif marks >= 50 and marks < 75:
# #     print("second class")
# # elif marks >= 35 and marks < 50:
# #     print("just pass")
# # # elif marks < 35:
# # #     print("fail")
# # else:
# #     print("fail")
# if marks > 100:
#     print("enter valid marks less than 100")
# elif marks >= 75:
#     print("first class")
# elif marks >= 50:
#     print("second class")
# elif marks >= 35:
#     print("just pass")
# else:
#     print("fail")


# positive or negative
# num = int(input("enter a number: "))

# if num > 0:
#     print("it is positive number")
# elif num < 0:
#     print("it is a negative number")
# else:
#     print("given number is zero")

'******************************************************************************'
# day_type = input("enter day type weekday/weekend: ")
#
# if day_type == "weekday":
#     print("go to office")
# elif day_type == "weekend":
#     # print("this is weekend")
#     activity_type = input("enter activity_type movie/trip/party: ")
#     if activity_type == "movie":
#         movie_type = input("enter movie_type ott/theatre: ")
#         if movie_type == 'ott':
#             print("watch movies in ott")
#         elif movie_type == "theatre":
#             print("watch movies in theatre")
#         else:
#             print("enter a valid movie_type ott/theatre")
#     elif activity_type == "trip":
#         trip_type = input("enter trip_type local/outstation: ")
#         if trip_type == "local":
#             print("go to local trip")
#         elif trip_type == "outstation":
#             print("go to outstation trip")
#         else:
#             print("enter a valid trip_type local/outstation")
#     elif activity_type == "party":
#         party_type = input("enter party_type house/outside: ")
#         if party_type == "house":
#             print("Yay house party")
#         elif party_type == "outside":
#             print("Yay outside party")
#         else:
#             print("enter a valid party_type house/outside")
#     else:
#         print("enter a valid activity_type movie/trip/party")
#
# else:
#     print("provide valid day type weekday/weekend")

