"""
Author : GOVIND
Date   : 02-07-2024
"""

# https://docs.python.org/3/library/array.html
"""
The array module in Python provides an alternative to Python's 
built-in list structure. 
While lists can contain elements of different types and dynamically resize, 
arrays are used to store elements of the same type and have a fixed size. 
Here's an explanation of arrays and their built-in methods, 
along with a comparison with lists and guidance on when to use arrays.

Array in Python:
----------------

An array in Python is a data structure that stores elements of the 
same type sequentially in memory. 
It's particularly useful when you need to work with a homogeneous collection of data.

To use arrays in Python, you first need to import the array module:


Creating Arrays:
----------------

You can create an array using the array() function from the array module.
It takes two arguments: the type code indicating the type of elements in the 
array and an iterable (such as a list) containing the initial values.

my_array = arr.array('i', [1, 2, 3, 4, 5])


In this example, 'i' represents signed integers.

Built-in Methods of Arrays:
---------------------------

1. append(x)        : Adds a single element x to the end of the array.

2. extend(iterable) : Adds elements from the iterable to the end of the array.

3. insert(i, x)     : Inserts element x at the position i in the array.

4. pop([i])         : Removes and returns the element at position i in the array.
                      If i is not specified, it removes and returns the last element.

5. remove(x)        : Removes the first occurrence of element x from the array.

6. index(x)         : Returns the index of the first occurrence of element x in the array.

7. count(x)         : Returns the number of occurrences of element x in the array.

8. reverse()        : Reverses the order of elements in the array.

9. tostring()       : Returns the array converted to a string.

10. fromstring(s)   : Creates an array from the string s.

11. tobytes()       : Returns the array converted to a bytes object.

12. frombytes(b)    : Creates an array from a bytes object.

13. tolist()        : Converts the array to a list.

List vs. Array:
---------------

- Flexibility        : Lists can contain elements of different types and can 
                       dynamically resize. 
                       Arrays are homogeneous and have a fixed size.

- Memory Efficiency  : Arrays are more memory efficient since they store 
                       elements of the same type in contiguous memory locations.

- Performance        : In some cases, array operations can be faster than 
                       equivalent list operations, especially when dealing 
                       with a large amount of numerical data.

Use arrays when:
----------------

- You need to work with a large amount of homogeneous numerical data.

- You need to perform mathematical operations efficiently on the data.

- You want to save memory by avoiding the overhead of storing type information for each element.
"""

import array
#
# # 'b' - signed integer (1 byte)
# signed_integers = array.array('b', [-128, 0, 127])
# print(signed_integers)
#
# # 'B' - unsigned integer (1 byte)
# unsigned_integers = array.array('B', [0, 255])
# print(unsigned_integers)
#
# # 'u' - Unicode character (2 bytes)
# unicode_characters = array.array('u', ['a', 'b', 'c'])
# print(unicode_characters)
#
# 'h' - signed integer (2 bytes)
# signed_integers_2bytes = array.array('h', [-32768, 0, 32767])
# print(signed_integers_2bytes)
#
# # 'H' - unsigned integer (2 bytes)
# unsigned_integers_2bytes = array.array('H', [0, 65535])
# print(unsigned_integers_2bytes)
#
# # 'i' - signed integer (2 bytes)
# signed_integers_2bytes = array.array('i', [-2147483648, 0, 2147483647])
# print(signed_integers_2bytes)
#
# # 'I' - unsigned integer (2 bytes)
# unsigned_integers_2bytes = array.array('I', [0, 4294967295])
# print(unsigned_integers_2bytes)
#
# # 'l' - signed integer (4 bytes)
# signed_integers_4bytes = array.array('l', [-2147483648, 0, 2147483647])
# print(signed_integers_4bytes)
#
# # 'L' - unsigned integer (4 bytes)

# unsigned_integers_4bytes = array.array('L', [0, 4294967295])
# print(unsigned_integers_4bytes)
"""
Note:
-----
'i': Typically a 4-byte signed integer on most systems.
'I': Typically a 4-byte unsigned integer on most systems.
'l' and 'L': These are typically 4-byte signed and unsigned long integers, respectively.

'i': Signed integer (at least 2 bytes, typically 4 bytes on most systems).
'l': Signed long integer (at least 4 bytes, but size can vary).
The size of 'i' and 'l' may vary based on the architecture (32-bit vs. 64-bit) and the specific implementation of Python. 
On many modern systems, both 'i' and 'l' are 4 bytes because 'int' and 'long' in C are often the same size.
"""

#
# # 'q' - signed integer (8 bytes)
# signed_integers_8bytes = array.array('q', [-9223372036854775808, 0, 9223372036854775807])
# print(signed_integers_8bytes)
#
# # 'Q' - unsigned integer (8 bytes)
# unsigned_integers_8bytes = array.array('Q', [0, 18446744073709551615])
# print(unsigned_integers_8bytes)
#
# # 'f' - floating point (4 bytes)
# floats_4bytes = array.array('f', [3.14, 2.718, 1.618])
# print(floats_4bytes)
#
# 'd' - floating point (8 bytes)
# floats_8bytes = array.array('d', [3.14159, 2.71828, 1.61803])
# print(floats_8bytes)
# floats_8bytes.append(2.33)
# print(floats_8bytes)
# for each in floats_8bytes:
#     print(each)
# print("\n", id(floats_8bytes[0]))
# print("\n", id(floats_8bytes[1]))
# print("\n", id(floats_8bytes[2]))
# print("\n", id(floats_8bytes[3]))

