"""
Author : GOVIND
Date   : 02-07-2024
"""
"""
A frozenset in Python is an immutable collection of unique elements, 
similar to a set but it cannot be changed once created. 
To create a frozenset, you can use the frozenset() constructor, 
passing in an iterable.
"""
# y = (1, 2, 3, 4, 5, 5)
# y = "python"
# y = range(5)
y = {"name":"rajesh", "age": 30}
# y = True
frz_set = frozenset(y)
print(frz_set)
print(type(frz_set))
# another_set = {4, 5, 6, 7, 8}
# print(another_set)

# # Union
# union_set = frz_set.union(another_set)
# print(union_set)
#
# # Intersection
# intersection_set = frz_set.intersection(another_set)
# print(intersection_set)
#
# # Difference
# difference_set = frz_set.difference(another_set)
# print(difference_set)
#
# # Is Disjoint
# is_disjoint = frz_set.isdisjoint(another_set)
# print(is_disjoint)

# is_superset = frz_set.issuperset(another_set)
# print(is_superset)

