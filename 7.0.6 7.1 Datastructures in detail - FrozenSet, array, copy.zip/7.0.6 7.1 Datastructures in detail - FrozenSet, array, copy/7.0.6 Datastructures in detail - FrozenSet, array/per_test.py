"""
Author : Govind
Date   : 02-07-2024
"""
import time
import copy
import array


# # Create a large list of integers
large_list = list(range(10000000))

start_time_shallow = time.time()
shallow_copied_data = copy.copy(large_list)
end_time_shallow = time.time()
time_diff_shallow = end_time_shallow - start_time_shallow
shallow_copy_time_list = time_diff_shallow


start_time_deepcopy = time.time()
deep_copied_data = copy.deepcopy(large_list)
end_time_deep_copy = time.time()
time_diff_deep_copy = end_time_deep_copy - start_time_deepcopy
deep_copy_time_list = time_diff_deep_copy

print("Performance comparison for Lists:")
print(f"Shallow Copy Time : {shallow_copy_time_list} seconds")
print(f"Deep Copy Time    : {deep_copy_time_list} seconds")



# Create a large array of integers
# large_array = array.array('i', list(range(10000000)))
#
# start_time_shallow_arr = time.time()
# shallow_copied_data_arr = copy.copy(large_array)
# end_time_shallow_arr = time.time()
# time_diff_shallow_arr = end_time_shallow_arr - start_time_shallow_arr
# shallow_copy_time_array = time_diff_shallow_arr
#
#
# start_time_deepcopy_arr = time.time()
# deep_copied_data_arr= copy.deepcopy(large_array)
# end_time_deep_copy_arr = time.time()
# time_diff_deep_copy_arr = end_time_deep_copy_arr - start_time_deepcopy_arr
# deep_copy_time_array = time_diff_deep_copy_arr

#
# print("\nPerformance comparison for Arrays:")
# print(f"Shallow Copy Time : {shallow_copy_time_array} seconds")
# print(f"Deep Copy Time    : {deep_copy_time_array} seconds")
