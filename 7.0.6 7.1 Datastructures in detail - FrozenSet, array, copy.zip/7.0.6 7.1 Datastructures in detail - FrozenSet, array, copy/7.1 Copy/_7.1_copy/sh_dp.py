"""
Author : KV 
Date   : 23-03-2024
"""

import copy

# original_list = [1, 2, [3, 4]]
# shallow_copied_list = copy.copy(original_list)

# print("**************************** shallow copy before modifying ****************************\n")
# print("before modifying original_list                 : ", original_list)
# print("before modifying shallow_copied_list           : ", shallow_copied_list)
# print("before modifying id of original_list           : ", id(original_list))
# print("before modifying id of shallow_copied_list     : ", id(shallow_copied_list))
# print("before modifying id of original_list[2]        : ", id(original_list[2]))
# print("before modifying id of shallow_copied_list[2]) : ", id(shallow_copied_list[2]))

# Modify the original list
# original_list[2][0] = 99
#
# print("\n**************************** shallow copy after modifying ****************************\n")
# print("after modifying original_list                 : ", original_list)
# print("after modifying shallow_copied_list           : ", shallow_copied_list)
# print("after modifying id of original_list           : ", id(original_list))
# print("after modifying id of shallow_copied_list     : ", id(shallow_copied_list))
# print("after modifying id of original_list[2]        : ", id(original_list[2]))
# print("after modifying id of shallow_copied_list[2]  : ", id(shallow_copied_list[2]))
# print("\n**************************** End of program ****************************\n")


# import copy
#
# original_list = [1, 2, [3, 4]]
# deep_copied_list = copy.deepcopy(original_list)
# print("**************************** deep copy before modifying ****************************\n")
# print("before modifying original_list              : ", original_list)
# print("before modifying deep_copied_list           : ", deep_copied_list)
# print("before modifying id of original_list        : ", id(original_list))
# print("before modifying id of deep_copied_list     : ", id(deep_copied_list))
# print("before modifying id of original_list[2]     : ", id(original_list[2]))
# print("before modifying id of deep_copied_list[2]) : ", id(deep_copied_list[2]))
#
# Modify the original list
# original_list[2][0] = 99
# print("\n**************************** deep copy after modifying ****************************\n")
#
# print("after modifying original_list               : ", original_list)
# print("after modifying deep_copied_list            : ", deep_copied_list)
# print("before modifying id of original_list        : ", id(original_list))
# print("before modifying id of deep_copied_list     : ", id(deep_copied_list))
# print("after modifying id of original_list[2]      : ", id(original_list[2]))
# print("after modifying id of deep_copied_list[2]   : ", id(deep_copied_list[2]))
