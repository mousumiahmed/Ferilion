"""
Author : GOVIND
Date   : 12-08-2024
"""
# math_ops.py

def add(x, y):
    return x + y

# def add(x, y):
#     if isinstance(x, int) and isinstance(y, int):
#         return x + y
#     else:
#         if not isinstance(x, int) and not isinstance(y, int):
#             return f"{x} which is of type {type(x)} and {y} which is of type {type(y)}"
#
#         elif not isinstance(x, int):
#             return f"you have provided {x} which is of type {type(x)}"
#         elif not isinstance(y, int):
#             return f"you have provided {y} which is of type {type(y)}"
#

def subtract(x, y):
    return x - y

def multiply(x, y):
    return x * y

def divide(x, y):
    if y == 0:
        raise ValueError("Cannot divide by zero")
    elif y > 2:
        return x / y


