"""
Author : GOVIND
Date   : 12-08-2024
"""
"""
setUp() method    : This method is called before each test method in the unittest class. 
                    Its purpose is to set up any necessary preconditions or resources needed 
                    for the test case. Initialize variables, set up database connections, 
                    or perform any other setup tasks that are common to multiple test cases 
                    within the class.

tearDown() method : This method is called after each test method in the unittest class. 
                    Its purpose is to clean up any resources or perform any necessary 
                    cleanup tasks after the test case has been executed. 
                    This could involve closing database connections, deleting 
                    temporary files, or releasing any resources that 
                    were allocated during the test.
"""

import unittest


class TestCaseExample(unittest.TestCase):
    def setUp(self):
        # Set up any preconditions or resources needed for the test case
        print("from setup")
        self.data = [1, 2, 3, 4, 5]

    def tearDown(self):
        # Clean up any resources after the test case
        print("teardown")
        del self.data

    def test_sum(self):
        # Test case to verify the sum of elements in a list
        result = sum(self.data)
        # print(self.data)
        self.assertEqual(result, 15)

    def test_append(self):
        # Test case to verify the append operation on a list
        self.data.append(6)
        print(self.data)
        self.assertEqual(len(self.data), 6)


if __name__ == '__main__':
    unittest.main()
