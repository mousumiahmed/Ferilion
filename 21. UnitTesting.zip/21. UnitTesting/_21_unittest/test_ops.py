"""
Author : GOVIND
Date   : 12-08-2024
"""
from ops import add
import unittest


class TestOps(unittest.TestCase):

    def test_add_int(self):
        res = add(2, 5)
        self.assertEqual(res, 7)

    def test_add_str(self):
        res = add("2", "5")
        self.assertEqual(res, "prov valid integers")

    def test_add_int_str(self):
        res = add(12, "5")
        self.assertEqual(res, "provide valid integers")


if __name__ == '__main__':
    unittest.main()
