"""
Author : GOVIND
Date   : 12-08-2024
"""
"""
unittesting 

correctness of the code
different scenarios

test_ops.py

import unittest

class TestMathsOps(unittest.Testcase):
    def test_add_two_int(self):
        pass
    def test_add_int_str(self):
        pass
        
if __name__ == '__main__':
    unittest.main()
    
    
"""
import unittest.main
# class TestMathsOps(unittest.Testcase):

def add(x,y):
    if isinstance(x, int) and isinstance(y, int):
        return x + y
    else:
        return "provide valid integers"

# print(add(10, "a"))